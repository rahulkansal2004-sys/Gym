import { describe, it, expect } from 'vitest';
import { planOccurrences, inQuietHours, stableId, toCapWeekday } from '../src/notifications/planner';
import { DEFAULT_REMINDERS } from '../src/db/repos';
import type { Reminder } from '../src/db/types';

const mk = (patch: Partial<Reminder>): Reminder => ({ id: 'r-' + patch.type, ...DEFAULT_REMINDERS.find((d) => d.type === patch.type)!, ...patch });

describe('notification planner', () => {
  it('quiet hours wrap midnight', () => {
    const q = { enabled: true, start: '22:00', end: '07:00' };
    expect(inQuietHours(23, 0, q)).toBe(true);
    expect(inQuietHours(6, 59, q)).toBe(true);
    expect(inQuietHours(7, 0, q)).toBe(false);
    expect(inQuietHours(12, 0, q)).toBe(false);
    expect(inQuietHours(23, 0, { ...q, enabled: false })).toBe(false);
  });

  it('expands interval reminders within the window and suppresses quiet-hour slots', () => {
    const water = mk({ type: 'water', enabled: true, intervalMinutes: 120, windowStart: '08:00', windowEnd: '22:00', days: [1] });
    const occ = planOccurrences([water], { enabled: true, start: '21:00', end: '07:00' }, false);
    expect(occ.map((o) => o.hour)).toEqual([8, 10, 12, 14, 16, 18, 20]); // 22:00 falls in quiet hours
  });

  it('fixed-time reminders fire on chosen days only; ids are stable and unique', () => {
    const w = mk({ type: 'workout', enabled: true, time: '07:00', days: [1, 3, 5] });
    const a = planOccurrences([w], { enabled: false, start: '', end: '' }, false);
    const b = planOccurrences([w], { enabled: false, start: '', end: '' }, false);
    expect(a.length).toBe(3);
    expect(a.map((o) => o.id)).toEqual(b.map((o) => o.id));
    expect(new Set(a.map((o) => o.id)).size).toBe(3);
  });

  it('disabled reminders and the global off switch produce nothing', () => {
    const w = mk({ type: 'workout', enabled: false, time: '07:00' });
    expect(planOccurrences([w], { enabled: false, start: '', end: '' }, false).length).toBe(0);
    const on = mk({ type: 'workout', enabled: true, time: '07:00' });
    expect(planOccurrences([on], { enabled: false, start: '', end: '' }, true).length).toBe(0);
  });

  it('never schedules two notifications of one type in the same slot', () => {
    const a = mk({ type: 'meal', id: 'a', enabled: true, time: '13:00', days: [1] });
    const b = mk({ type: 'meal', id: 'b', enabled: true, time: '13:00', days: [1] });
    expect(planOccurrences([a, b], { enabled: false, start: '', end: '' }, false).length).toBe(1);
  });

  it('weekday mapping and id hashing', () => {
    expect(toCapWeekday(1)).toBe(2); // Monday
    expect(toCapWeekday(7)).toBe(1); // Sunday
    expect(stableId('x')).toBe(stableId('x'));
    expect(stableId('x')).not.toBe(stableId('y'));
    expect(stableId('x')).toBeGreaterThan(0);
  });
});

import initSqlJs from 'sql.js';
import { SqlJsDriver } from '../src/db/sqljs';
import { migrateAndSeed } from '../src/db';

export async function freshDb(): Promise<SqlJsDriver> {
  const SQL = await initSqlJs();
  const d = await SqlJsDriver.open(SQL);
  await migrateAndSeed(d);
  return d;
}

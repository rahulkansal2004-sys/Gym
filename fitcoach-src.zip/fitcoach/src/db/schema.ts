// SQLite schema, applied as ordered migrations. Never edit a shipped migration; append a new one.
export const MIGRATIONS: { version: number; statements: string[] }[] = [
  {
    version: 1,
    statements: [
      `CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)`,

      `CREATE TABLE IF NOT EXISTS profile (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        name TEXT,
        dob TEXT,
        sex TEXT,
        height_cm REAL,
        weight_kg REAL,
        target_weight_kg REAL,
        waist_cm REAL,
        experience TEXT NOT NULL DEFAULT 'beginner-some',
        activity_level TEXT NOT NULL DEFAULT 'light',
        days_per_week INTEGER NOT NULL DEFAULT 3,
        session_minutes INTEGER NOT NULL DEFAULT 45,
        equipment TEXT NOT NULL DEFAULT '["bodyweight"]',
        location TEXT NOT NULL DEFAULT 'home',
        diet TEXT NOT NULL DEFAULT 'vegetarian',
        restrictions TEXT NOT NULL DEFAULT '[]',
        restriction_notes TEXT,
        restrictions_confirmed_at TEXT,
        exclude_glute_isolation INTEGER NOT NULL DEFAULT 0,
        sleep_hours REAL,
        units_weight TEXT NOT NULL DEFAULT 'kg',
        units_length TEXT NOT NULL DEFAULT 'cm',
        units_volume TEXT NOT NULL DEFAULT 'ml',
        timezone TEXT,
        nutrition_enabled INTEGER NOT NULL DEFAULT 1,
        onboarding_complete INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )`,

      `CREATE TABLE IF NOT EXISTS goals (
        id TEXT PRIMARY KEY,
        primary_goal TEXT NOT NULL,
        secondary_goal TEXT,
        custom_text TEXT,
        active INTEGER NOT NULL DEFAULT 1,
        set_at TEXT NOT NULL
      )`,

      `CREATE TABLE IF NOT EXISTS exercises (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        movement_pattern TEXT NOT NULL,
        category TEXT NOT NULL,
        difficulty TEXT NOT NULL,
        is_custom INTEGER NOT NULL DEFAULT 0,
        json TEXT NOT NULL
      )`,
      `CREATE INDEX IF NOT EXISTS idx_exercises_pattern ON exercises(movement_pattern)`,

      `CREATE TABLE IF NOT EXISTS programmes (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        template TEXT NOT NULL,
        goal TEXT NOT NULL,
        days_per_week INTEGER NOT NULL,
        weeks INTEGER NOT NULL,
        start_date TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'active',
        config_json TEXT NOT NULL,
        created_at TEXT NOT NULL
      )`,

      `CREATE TABLE IF NOT EXISTS planned_workouts (
        id TEXT PRIMARY KEY,
        programme_id TEXT NOT NULL REFERENCES programmes(id),
        week INTEGER NOT NULL,
        day_index INTEGER NOT NULL,
        scheduled_date TEXT NOT NULL,
        name TEXT NOT NULL,
        focus TEXT NOT NULL,
        exercises_json TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'planned',
        estimated_minutes INTEGER NOT NULL DEFAULT 45
      )`,
      `CREATE INDEX IF NOT EXISTS idx_planned_date ON planned_workouts(scheduled_date)`,

      `CREATE TABLE IF NOT EXISTS sessions (
        id TEXT PRIMARY KEY,
        planned_workout_id TEXT,
        programme_id TEXT,
        name TEXT NOT NULL,
        started_at TEXT NOT NULL,
        ended_at TEXT,
        status TEXT NOT NULL DEFAULT 'in_progress',
        duration_s INTEGER,
        rpe INTEGER,
        notes TEXT,
        state_json TEXT
      )`,
      `CREATE INDEX IF NOT EXISTS idx_sessions_started ON sessions(started_at)`,

      `CREATE TABLE IF NOT EXISTS exercise_logs (
        id TEXT PRIMARY KEY,
        session_id TEXT NOT NULL REFERENCES sessions(id),
        exercise_id TEXT NOT NULL,
        order_index INTEGER NOT NULL,
        planned_sets INTEGER NOT NULL,
        rep_min INTEGER NOT NULL,
        rep_max INTEGER NOT NULL,
        rest_seconds INTEGER NOT NULL,
        substituted_from TEXT,
        substitution_reason TEXT,
        skipped INTEGER NOT NULL DEFAULT 0,
        pain_reported INTEGER NOT NULL DEFAULT 0,
        notes TEXT
      )`,

      `CREATE TABLE IF NOT EXISTS set_logs (
        id TEXT PRIMARY KEY,
        exercise_log_id TEXT NOT NULL REFERENCES exercise_logs(id),
        session_id TEXT NOT NULL,
        exercise_id TEXT NOT NULL,
        set_index INTEGER NOT NULL,
        weight_kg REAL NOT NULL DEFAULT 0,
        reps INTEGER NOT NULL DEFAULT 0,
        completed INTEGER NOT NULL DEFAULT 0,
        rpe INTEGER,
        logged_at TEXT NOT NULL
      )`,
      `CREATE INDEX IF NOT EXISTS idx_setlogs_exercise ON set_logs(exercise_id, logged_at)`,

      `CREATE TABLE IF NOT EXISTS personal_records (
        id TEXT PRIMARY KEY,
        exercise_id TEXT NOT NULL,
        type TEXT NOT NULL,
        weight_kg REAL NOT NULL,
        reps INTEGER NOT NULL,
        value REAL NOT NULL,
        set_log_id TEXT NOT NULL,
        achieved_at TEXT NOT NULL
      )`,

      `CREATE TABLE IF NOT EXISTS foods (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        category TEXT NOT NULL,
        vegetarian INTEGER NOT NULL,
        is_custom INTEGER NOT NULL DEFAULT 0,
        json TEXT NOT NULL
      )`,

      `CREATE TABLE IF NOT EXISTS nutrition_entries (
        id TEXT PRIMARY KEY,
        local_date TEXT NOT NULL,
        meal TEXT NOT NULL,
        food_id TEXT,
        food_name TEXT NOT NULL,
        grams REAL NOT NULL,
        kcal REAL NOT NULL,
        protein REAL NOT NULL,
        carbs REAL NOT NULL,
        fat REAL NOT NULL,
        fibre REAL NOT NULL,
        source TEXT NOT NULL,
        logged_at TEXT NOT NULL,
        deleted_at TEXT
      )`,
      `CREATE INDEX IF NOT EXISTS idx_nutrition_date ON nutrition_entries(local_date)`,

      `CREATE TABLE IF NOT EXISTS saved_meals (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        items_json TEXT NOT NULL,
        created_at TEXT NOT NULL
      )`,

      `CREATE TABLE IF NOT EXISTS hydration_entries (
        id TEXT PRIMARY KEY,
        local_date TEXT NOT NULL,
        amount_ml INTEGER NOT NULL,
        logged_at TEXT NOT NULL,
        tz_offset_min INTEGER NOT NULL,
        deleted_at TEXT
      )`,
      `CREATE INDEX IF NOT EXISTS idx_hydration_date ON hydration_entries(local_date)`,

      `CREATE TABLE IF NOT EXISTS measurements (
        id TEXT PRIMARY KEY,
        local_date TEXT NOT NULL,
        type TEXT NOT NULL,
        value REAL NOT NULL,
        unit TEXT NOT NULL,
        note TEXT,
        logged_at TEXT NOT NULL,
        deleted_at TEXT
      )`,
      `CREATE INDEX IF NOT EXISTS idx_measure_type ON measurements(type, local_date)`,

      `CREATE TABLE IF NOT EXISTS progress_photos (
        id TEXT PRIMARY KEY,
        local_date TEXT NOT NULL,
        file_path TEXT NOT NULL,
        consent INTEGER NOT NULL DEFAULT 1,
        note TEXT,
        logged_at TEXT NOT NULL
      )`,

      `CREATE TABLE IF NOT EXISTS recovery_entries (
        id TEXT PRIMARY KEY,
        local_date TEXT NOT NULL,
        sleep_hours REAL,
        sleep_quality INTEGER,
        energy INTEGER,
        soreness INTEGER,
        recovery INTEGER,
        stress INTEGER,
        readiness INTEGER,
        source TEXT NOT NULL DEFAULT 'manual',
        logged_at TEXT NOT NULL
      )`,
      `CREATE INDEX IF NOT EXISTS idx_recovery_date ON recovery_entries(local_date)`,

      `CREATE TABLE IF NOT EXISTS reminders (
        id TEXT PRIMARY KEY,
        type TEXT NOT NULL,
        label TEXT NOT NULL,
        enabled INTEGER NOT NULL DEFAULT 0,
        time TEXT,
        days_json TEXT NOT NULL DEFAULT '[1,2,3,4,5,6,7]',
        interval_minutes INTEGER,
        window_start TEXT,
        window_end TEXT,
        snoozed_until TEXT
      )`,

      `CREATE TABLE IF NOT EXISTS wearable_connections (
        provider TEXT PRIMARY KEY,
        status TEXT NOT NULL,
        scopes_json TEXT NOT NULL DEFAULT '[]',
        last_sync_at TEXT,
        last_error TEXT,
        connected_at TEXT
      )`,

      `CREATE TABLE IF NOT EXISTS wearable_samples (
        id TEXT PRIMARY KEY,
        provider TEXT NOT NULL,
        type TEXT NOT NULL,
        value REAL NOT NULL,
        unit TEXT NOT NULL,
        start_at TEXT NOT NULL,
        end_at TEXT NOT NULL,
        source_id TEXT NOT NULL,
        synced_at TEXT NOT NULL,
        UNIQUE(provider, type, start_at, source_id)
      )`,

      `CREATE TABLE IF NOT EXISTS sync_history (
        id TEXT PRIMARY KEY,
        provider TEXT NOT NULL,
        started_at TEXT NOT NULL,
        finished_at TEXT,
        status TEXT NOT NULL,
        records INTEGER NOT NULL DEFAULT 0,
        error TEXT
      )`,

      `CREATE TABLE IF NOT EXISTS ai_log (
        id TEXT PRIMARY KEY,
        kind TEXT NOT NULL,
        mode TEXT NOT NULL,
        prompt_chars INTEGER NOT NULL,
        response TEXT,
        status TEXT NOT NULL,
        created_at TEXT NOT NULL
      )`,

      `CREATE TABLE IF NOT EXISTS improvement_requests (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        body TEXT NOT NULL,
        category TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'submitted',
        ai_analysis TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )`,

      `CREATE TABLE IF NOT EXISTS programme_reviews (
        id TEXT PRIMARY KEY,
        programme_id TEXT NOT NULL,
        week INTEGER NOT NULL,
        summary_json TEXT NOT NULL,
        decision TEXT,
        created_at TEXT NOT NULL
      )`,

      `CREATE TABLE IF NOT EXISTS audit (
        id TEXT PRIMARY KEY,
        entity TEXT NOT NULL,
        entity_id TEXT,
        action TEXT NOT NULL,
        detail TEXT,
        at TEXT NOT NULL
      )`,
    ],
  },
];

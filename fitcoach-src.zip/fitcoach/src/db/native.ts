import { CapacitorSQLite, SQLiteConnection, type SQLiteDBConnection } from '@capacitor-community/sqlite';
import type { SqlDriver, SqlValue } from './driver';

const DB_NAME = 'fitcoach';

/** Android (and iOS) driver backed by the device's SQLite file via @capacitor-community/sqlite. */
export class NativeSqliteDriver implements SqlDriver {
  private constructor(private db: SQLiteDBConnection) {}

  static async open(): Promise<NativeSqliteDriver> {
    const sqlite = new SQLiteConnection(CapacitorSQLite);
    const consistency = await sqlite.checkConnectionsConsistency();
    const exists = (await sqlite.isConnection(DB_NAME, false)).result;
    const db = consistency.result && exists
      ? await sqlite.retrieveConnection(DB_NAME, false)
      : await sqlite.createConnection(DB_NAME, false, 'no-encryption', 1, false);
    await db.open();
    await db.execute('PRAGMA foreign_keys = ON;', false);
    return new NativeSqliteDriver(db);
  }

  async run(sql: string, params: SqlValue[] = []) {
    const r = await this.db.run(sql, params, false);
    return { changes: r.changes?.changes ?? 0 };
  }

  async query<T = Record<string, SqlValue>>(sql: string, params: SqlValue[] = []): Promise<T[]> {
    const r = await this.db.query(sql, params);
    return (r.values ?? []) as T[];
  }

  async batch(statements: { sql: string; params?: SqlValue[] }[]) {
    if (statements.length === 0) return;
    await this.db.executeSet(
      statements.map((s) => ({ statement: s.sql, values: s.params ?? [] })),
      true,
    );
  }

  async exportJson() {
    const tables = await this.query<{ name: string }>(
      `SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'`,
    );
    const out: Record<string, Record<string, SqlValue>[]> = {};
    for (const t of tables) out[t.name] = await this.query(`SELECT * FROM "${t.name}"`);
    return out;
  }

  async close() {
    await this.db.close();
  }
}

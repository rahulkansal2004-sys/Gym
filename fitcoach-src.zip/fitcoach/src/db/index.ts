import type { SqlDriver, SqlValue } from './driver';
import { MIGRATIONS } from './schema';
import { EXERCISES } from '../data/exercises';
import { FOODS } from '../data/foods';
import { nowIso } from '../lib/time';

export type { SqlDriver, SqlValue } from './driver';

let driver: SqlDriver | null = null;

export function setDriver(d: SqlDriver) {
  driver = d;
}

export function db(): SqlDriver {
  if (!driver) throw new Error('Database not initialised');
  return driver;
}

export async function getSetting(key: string): Promise<string | null> {
  const rows = await db().query<{ value: string }>('SELECT value FROM settings WHERE key = ?', [key]);
  return rows[0]?.value ?? null;
}

export async function setSetting(key: string, value: string): Promise<void> {
  await db().run('INSERT INTO settings(key, value) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value', [key, value]);
}

/** Apply pending migrations, then seed reference content (exercises, foods) that is not yet present. */
export async function migrateAndSeed(d: SqlDriver): Promise<void> {
  setDriver(d);
  await d.run('CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)');
  const current = Number((await getSetting('schema_version')) ?? '0');
  for (const m of MIGRATIONS) {
    if (m.version <= current) continue;
    await d.batch(m.statements.map((sql) => ({ sql })));
    await setSetting('schema_version', String(m.version));
  }
  await seedReferenceContent(d);
}

export const CONTENT_VERSION = 1;

/** Insert or refresh built-in exercises and foods. Custom (user-created) rows are never touched. */
export async function seedReferenceContent(d: SqlDriver, force = false): Promise<void> {
  const seeded = Number((await getSetting('content_version')) ?? '0');
  if (seeded >= CONTENT_VERSION && !force) return;
  const stmts: { sql: string; params: SqlValue[] }[] = [];
  for (const e of EXERCISES) {
    stmts.push({
      sql: `INSERT INTO exercises(id, name, movement_pattern, category, difficulty, is_custom, json)
            VALUES(?, ?, ?, ?, ?, 0, ?)
            ON CONFLICT(id) DO UPDATE SET name = excluded.name, movement_pattern = excluded.movement_pattern,
              category = excluded.category, difficulty = excluded.difficulty, json = excluded.json
            WHERE exercises.is_custom = 0`,
      params: [e.id, e.name, e.movementPattern, e.category, e.difficulty, JSON.stringify(e)],
    });
  }
  for (const f of FOODS) {
    stmts.push({
      sql: `INSERT INTO foods(id, name, category, vegetarian, is_custom, json) VALUES(?, ?, ?, ?, 0, ?)
            ON CONFLICT(id) DO UPDATE SET name = excluded.name, category = excluded.category,
              vegetarian = excluded.vegetarian, json = excluded.json WHERE foods.is_custom = 0`,
      params: [f.id, f.name, f.category, f.vegetarian ? 1 : 0, JSON.stringify(f)],
    });
  }
  await d.batch(stmts);
  await setSetting('content_version', String(CONTENT_VERSION));
  await setSetting('content_seeded_at', nowIso());
}

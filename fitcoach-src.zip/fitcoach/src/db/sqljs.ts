import type { SqlDriver, SqlValue } from './driver';
import type { Database, SqlJsStatic } from 'sql.js';

export interface SqlJsPersistence {
  load(): Promise<Uint8Array | null>;
  save(bytes: Uint8Array): Promise<void>;
}

/**
 * sql.js (WASM) driver. Used by the browser dev preview (with optional persistence)
 * and by automated tests (in memory). On Android the native driver is used instead.
 */
export class SqlJsDriver implements SqlDriver {
  private saveTimer: ReturnType<typeof setTimeout> | null = null;

  private constructor(private db: Database, private persistence?: SqlJsPersistence) {}

  static async open(SQL: SqlJsStatic, persistence?: SqlJsPersistence): Promise<SqlJsDriver> {
    const bytes = persistence ? await persistence.load() : null;
    const db = bytes ? new SQL.Database(bytes) : new SQL.Database();
    db.run('PRAGMA foreign_keys = ON;');
    return new SqlJsDriver(db, persistence);
  }

  private scheduleSave() {
    if (!this.persistence) return;
    if (this.saveTimer) clearTimeout(this.saveTimer);
    this.saveTimer = setTimeout(() => {
      void this.persistence?.save(this.db.export());
    }, 100);
  }

  async run(sql: string, params: SqlValue[] = []) {
    this.db.run(sql, params);
    const changes = this.db.getRowsModified();
    this.scheduleSave();
    return { changes };
  }

  async query<T = Record<string, SqlValue>>(sql: string, params: SqlValue[] = []): Promise<T[]> {
    const stmt = this.db.prepare(sql);
    stmt.bind(params);
    const rows: T[] = [];
    while (stmt.step()) rows.push(stmt.getAsObject() as T);
    stmt.free();
    return rows;
  }

  async batch(statements: { sql: string; params?: SqlValue[] }[]) {
    this.db.run('BEGIN');
    try {
      for (const s of statements) this.db.run(s.sql, s.params ?? []);
      this.db.run('COMMIT');
    } catch (e) {
      this.db.run('ROLLBACK');
      throw e;
    }
    this.scheduleSave();
  }

  async exportJson() {
    const tables = await this.query<{ name: string }>(
      `SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'`,
    );
    const out: Record<string, Record<string, SqlValue>[]> = {};
    for (const t of tables) out[t.name] = await this.query(`SELECT * FROM "${t.name}"`);
    return out;
  }

  async flush() {
    if (this.saveTimer) clearTimeout(this.saveTimer);
    if (this.persistence) await this.persistence.save(this.db.export());
  }

  async close() {
    await this.flush();
    this.db.close();
  }
}

import type { Equipment, BodyArea, ExerciseSeed } from '../data/exercises';
import type { FoodSeed } from '../data/foods';

export type Experience = 'new' | 'beginner-some' | 'intermediate' | 'advanced' | 'unsure';
export type ActivityLevel = 'sedentary' | 'light' | 'moderate' | 'active' | 'very-active';
export type Diet = 'vegetarian' | 'eggetarian' | 'non-vegetarian' | 'vegan';
export type Sex = 'male' | 'female' | 'unspecified';
export type GoalId =
  | 'lean' | 'muscular' | 'athletic' | 'toned' | 'fat-loss' | 'muscle-gain'
  | 'strength' | 'endurance' | 'general-health' | 'custom';

export interface Profile {
  name: string | null;
  dob: string | null;
  sex: Sex | null;
  heightCm: number | null;
  weightKg: number | null;
  targetWeightKg: number | null;
  waistCm: number | null;
  experience: Experience;
  activityLevel: ActivityLevel;
  daysPerWeek: number;
  sessionMinutes: number;
  equipment: Equipment[];
  location: 'gym' | 'home' | 'both';
  diet: Diet;
  restrictions: BodyArea[];
  restrictionNotes: string | null;
  restrictionsConfirmedAt: string | null;
  excludeGluteIsolation: boolean;
  sleepHours: number | null;
  unitsWeight: 'kg' | 'lb';
  unitsLength: 'cm' | 'in';
  unitsVolume: 'ml' | 'floz';
  timezone: string | null;
  nutritionEnabled: boolean;
  onboardingComplete: boolean;
}

export interface Goal {
  id: string;
  primaryGoal: GoalId;
  secondaryGoal: GoalId | null;
  customText: string | null;
  active: boolean;
  setAt: string;
}

export type Exercise = ExerciseSeed & { isCustom?: boolean };
export type Food = FoodSeed & { isCustom?: boolean };

export interface PlannedExercise {
  exerciseId: string;
  sets: number;
  repMin: number;
  repMax: number;
  restSeconds: number;
  durationMinutes?: number;
  suggestedKg?: number | null;
  suggestionReason?: string;
  role: 'main' | 'secondary' | 'accessory' | 'cardio' | 'mobility';
}

export interface PlannedWorkout {
  id: string;
  programmeId: string;
  week: number;
  dayIndex: number;
  scheduledDate: string;
  name: string;
  focus: string;
  exercises: PlannedExercise[];
  status: 'planned' | 'done' | 'skipped' | 'rescheduled' | 'partial';
  estimatedMinutes: number;
}

export interface Programme {
  id: string;
  name: string;
  template: string;
  goal: GoalId;
  daysPerWeek: number;
  weeks: number;
  startDate: string;
  status: 'active' | 'archived' | 'completed';
  config: Record<string, unknown>;
  createdAt: string;
}

export interface Session {
  id: string;
  plannedWorkoutId: string | null;
  programmeId: string | null;
  name: string;
  startedAt: string;
  endedAt: string | null;
  status: 'in_progress' | 'completed' | 'abandoned';
  durationS: number | null;
  rpe: number | null;
  notes: string | null;
}

export interface ExerciseLog {
  id: string;
  sessionId: string;
  exerciseId: string;
  orderIndex: number;
  plannedSets: number;
  repMin: number;
  repMax: number;
  restSeconds: number;
  substitutedFrom: string | null;
  substitutionReason: string | null;
  skipped: boolean;
  painReported: boolean;
  notes: string | null;
}

export interface SetLog {
  id: string;
  exerciseLogId: string;
  sessionId: string;
  exerciseId: string;
  setIndex: number;
  weightKg: number;
  reps: number;
  completed: boolean;
  rpe: number | null;
  loggedAt: string;
}

export interface PersonalRecord {
  id: string;
  exerciseId: string;
  type: 'heaviest' | 'most-reps-at-weight' | 'best-e1rm';
  weightKg: number;
  reps: number;
  value: number;
  setLogId: string;
  achievedAt: string;
}

export interface NutritionEntry {
  id: string;
  localDate: string;
  meal: 'breakfast' | 'lunch' | 'snack' | 'dinner' | 'other';
  foodId: string | null;
  foodName: string;
  grams: number;
  kcal: number;
  protein: number;
  carbs: number;
  fat: number;
  fibre: number;
  source: 'label' | 'database' | 'ai-estimate' | 'manual';
  loggedAt: string;
}

export interface HydrationEntry {
  id: string;
  localDate: string;
  amountMl: number;
  loggedAt: string;
}

export type MeasurementType = 'weight' | 'waist' | 'chest' | 'arm' | 'thigh' | 'hips' | 'neck' | 'custom';

export interface Measurement {
  id: string;
  localDate: string;
  type: MeasurementType | string;
  value: number;
  unit: string;
  note: string | null;
  loggedAt: string;
}

export interface RecoveryEntry {
  id: string;
  localDate: string;
  sleepHours: number | null;
  sleepQuality: number | null;
  energy: number | null;
  soreness: number | null;
  recovery: number | null;
  stress: number | null;
  readiness: number | null;
  source: 'manual' | 'wearable';
  loggedAt: string;
}

export type ReminderType =
  | 'workout' | 'missed-workout' | 'water' | 'meal' | 'movement' | 'cardio'
  | 'bedtime' | 'measurement' | 'weekly-review' | 'block-review';

export interface Reminder {
  id: string;
  type: ReminderType;
  label: string;
  enabled: boolean;
  time: string | null; // HH:MM for fixed-time reminders
  days: number[]; // ISO weekdays 1..7
  intervalMinutes: number | null; // for repeating reminders such as water
  windowStart: string | null; // HH:MM
  windowEnd: string | null; // HH:MM
  snoozedUntil: string | null;
}

import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import * as repo from '../db/repos';
import type { Goal, Profile, Programme, Session } from '../db/types';

interface AppState {
  ready: boolean;
  profile: Profile;
  goal: Goal | null;
  programme: Programme | null;
  inProgress: Session | null;
  refresh: () => Promise<void>;
  toast: (msg: string) => void;
  toastMsg: string | null;
}

const Ctx = createContext<AppState | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [goal, setGoal] = useState<Goal | null>(null);
  const [programme, setProgramme] = useState<Programme | null>(null);
  const [inProgress, setInProgress] = useState<Session | null>(null);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    const [p, g, pr, s] = await Promise.all([repo.getProfile(), repo.getActiveGoal(), repo.getActiveProgramme(), repo.getInProgressSession()]);
    setProfile(p); setGoal(g); setProgramme(pr); setInProgress(s); setReady(true);
  }, []);

  useEffect(() => { void refresh(); }, [refresh]);

  const toast = useCallback((msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2600);
  }, []);

  const value = useMemo<AppState | null>(() => (profile ? { ready, profile, goal, programme, inProgress, refresh, toast, toastMsg } : null), [ready, profile, goal, programme, inProgress, refresh, toast, toastMsg]);
  if (!value) return null;
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useApp(): AppState {
  const v = useContext(Ctx);
  if (!v) throw new Error('useApp outside provider');
  return v;
}

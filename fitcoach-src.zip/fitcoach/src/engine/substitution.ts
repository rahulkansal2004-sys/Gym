import type { Exercise, Profile } from '../db/types';
import type { BodyArea } from '../data/exercises';
import { isAllowed } from './programme';

export type SubstitutionReason = 'equipment' | 'location' | 'discomfort' | 'preference' | 'difficulty' | 'time';

export interface SubstituteOption {
  exercise: Exercise;
  why: string;
}

export const RED_FLAG_SYMPTOMS = ['chest pain', 'chest tightness', 'faint', 'dizzy', 'breathless', 'short of breath', 'numb', 'swelling', 'sharp pain', 'pop', 'gave way'];

export interface SafetyAssessment {
  level: 'emergency' | 'stop' | 'modify';
  message: string;
}

/** Conservative triage of a free-text symptom report. Never a diagnosis. */
export function assessSymptom(text: string, area: BodyArea | null): SafetyAssessment {
  const t = text.toLowerCase();
  if (['chest pain', 'chest tightness', 'faint', 'short of breath', 'severe breathless', 'collapsed'].some((k) => t.includes(k))) {
    return {
      level: 'emergency',
      message: 'Stop exercising now. Chest pain, fainting or severe breathlessness during exercise need urgent medical attention. Call your local emergency number or get to emergency care.',
    };
  }
  if (['sharp', 'pop', 'gave way', 'numb', 'tingling', 'swelling', 'swollen', 'cannot bear weight', "can't bear weight"].some((k) => t.includes(k))) {
    return {
      level: 'stop',
      message: 'This sounds like something to have assessed rather than train around. Stop this session, avoid loading the area, and see a doctor or physiotherapist before resuming exercises that stress it.',
    };
  }
  return {
    level: 'modify',
    message: area
      ? `Noted. Exercises that load the ${area} will be avoided for this session. If the discomfort persists beyond a few days, have it checked.`
      : 'Noted. Choose a substitute that feels pain-free, keep the load light, and stop if it worsens.',
  };
}

export function suggestSubstitutes(
  target: Exercise,
  reason: SubstitutionReason,
  profile: Profile,
  all: Exercise[],
  extraAvoid: BodyArea[] = [],
  limit = 4,
): SubstituteOption[] {
  const effective: Profile = { ...profile, restrictions: [...new Set([...profile.restrictions, ...extraAvoid])] };
  const sameDay = new Set<string>();
  const candidates = all.filter((e) => e.id !== target.id && !sameDay.has(e.id) && isAllowed(e, effective));
  const explicit = new Set(target.substitutions);
  const easier = target.easierVariation;
  const score = (e: Exercise): number => {
    let s = 0;
    if (e.movementPattern !== target.movementPattern) s += 20;
    if (!e.primaryMuscles.some((m) => target.primaryMuscles.includes(m))) s += 15;
    if (explicit.has(e.id)) s -= 10;
    if (reason === 'difficulty' && e.id === easier) s -= 12;
    if (reason === 'time' && e.category === 'compound') s -= 3;
    if (reason === 'discomfort' && e.equipment.includes('machine')) s -= 2; // more stable path
    if (reason === 'discomfort' && e.contraindications.some((c) => target.contraindications.includes(c))) s += 6;
    s += Math.abs(rank(e.difficulty) - rank(target.difficulty));
    return s;
  };
  const rank = (d: Exercise['difficulty']) => (d === 'beginner' ? 0 : d === 'intermediate' ? 1 : 2);
  return candidates
    .map((e) => ({ e, s: score(e) }))
    .sort((a, b) => a.s - b.s || a.e.name.localeCompare(b.e.name))
    .slice(0, limit)
    .map(({ e }) => ({ exercise: e, why: whyText(target, e, reason, explicit.has(e.id)) }));
}

function whyText(target: Exercise, e: Exercise, reason: SubstitutionReason, explicit: boolean): string {
  const parts: string[] = [];
  if (e.movementPattern === target.movementPattern) parts.push(`same ${target.movementPattern.replace('-', ' ')} pattern`);
  else parts.push(`trains ${e.primaryMuscles.join(', ')} like the original`);
  if (explicit) parts.push('a listed alternative');
  if (reason === 'equipment' || reason === 'location') parts.push(`needs only ${e.equipment.join(' + ')}`);
  if (reason === 'difficulty') parts.push(`${e.difficulty} level`);
  if (reason === 'discomfort') parts.push('loads the area differently; keep it light and pain-free');
  return parts.join(', ');
}

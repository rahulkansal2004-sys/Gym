// Weekly review built only from recorded data. Deterministic; used on its own and as the
// evidence block handed to Gemini (which may only rephrase and explain, never invent).
import type { Exercise, Measurement, PlannedWorkout, RecoveryEntry, Session, SetLog } from '../db/types';
import { estimateOneRm } from './progression';

export interface WeeklyReviewInput {
  weekStart: string; // YYYY-MM-DD
  weekEnd: string;
  planned: PlannedWorkout[]; // planned in the window
  sessions: Session[]; // completed in the window
  sets: SetLog[]; // completed sets in the window
  previousSets: SetLog[]; // completed sets in the window before
  recovery: RecoveryEntry[];
  hydration: { date: string; ml: number }[];
  hydrationTargetMl: number;
  nutrition: { date: string; kcal: number; protein: number }[] | null;
  measurements: Measurement[]; // last ~5 weeks
  exercises: Map<string, Exercise>;
}

export interface Recommendation {
  id: string;
  title: string;
  why: string;
  action: 'keep' | 'progress' | 'hold' | 'deload' | 'schedule' | 'habit';
}

export interface WeeklyReview {
  summary: string;
  adherence: { planned: number; completed: number; partial: number };
  strength: { exerciseId: string; name: string; bestE1rm: number | null; prevE1rm: number | null; trend: 'up' | 'flat' | 'down' | 'new' }[];
  recovery: { avgSleep: number | null; avgSoreness: number | null; avgRecovery: number | null; days: number };
  hydration: { daysOnTarget: number; daysLogged: number; avgMl: number };
  nutrition: { daysLogged: number; avgKcal: number; avgProtein: number } | null;
  measurements: { type: string; latest: number; change: number | null; unit: string }[];
  achievements: string[];
  improvements: string[];
  recommendations: Recommendation[];
  dataGaps: string[];
}

export function buildWeeklyReview(i: WeeklyReviewInput): WeeklyReview {
  const planned = i.planned.length;
  const completed = i.planned.filter((p) => p.status === 'done').length;
  const partial = i.planned.filter((p) => p.status === 'partial').length;
  const dataGaps: string[] = [];

  // Strength trend per exercise (best estimated 1RM this week vs previous window)
  const byEx = group(i.sets.filter((s) => s.completed), (s) => s.exerciseId);
  const prevByEx = group(i.previousSets.filter((s) => s.completed), (s) => s.exerciseId);
  const strength: WeeklyReview['strength'] = [];
  for (const [exId, sets] of byEx) {
    const best = bestE1(sets);
    const prev = prevByEx.has(exId) ? bestE1(prevByEx.get(exId)!) : null;
    const trend: 'up' | 'flat' | 'down' | 'new' = prev == null || best == null ? 'new' : best > prev * 1.02 ? 'up' : best < prev * 0.98 ? 'down' : 'flat';
    strength.push({ exerciseId: exId, name: i.exercises.get(exId)?.name ?? exId, bestE1rm: best, prevE1rm: prev, trend });
  }
  strength.sort((a, b) => (b.bestE1rm ?? 0) - (a.bestE1rm ?? 0));

  const avg = (xs: (number | null)[]) => { const v = xs.filter((x): x is number => x != null); return v.length ? Math.round((v.reduce((a, b) => a + b, 0) / v.length) * 10) / 10 : null; };
  const recovery = {
    avgSleep: avg(i.recovery.map((r) => r.sleepHours)), avgSoreness: avg(i.recovery.map((r) => r.soreness)),
    avgRecovery: avg(i.recovery.map((r) => r.recovery)), days: i.recovery.length,
  };
  if (i.recovery.length < 3) dataGaps.push('Fewer than three recovery check-ins this week, so recovery-based advice is limited.');

  const hyd = { daysLogged: i.hydration.length, daysOnTarget: i.hydration.filter((h) => h.ml >= i.hydrationTargetMl).length,
    avgMl: i.hydration.length ? Math.round(i.hydration.reduce((a, h) => a + h.ml, 0) / i.hydration.length) : 0 };

  const nutrition = i.nutrition && i.nutrition.length
    ? { daysLogged: i.nutrition.length, avgKcal: Math.round(i.nutrition.reduce((a, n) => a + n.kcal, 0) / i.nutrition.length),
        avgProtein: Math.round(i.nutrition.reduce((a, n) => a + n.protein, 0) / i.nutrition.length) }
    : null;

  const measurements: WeeklyReview['measurements'] = [];
  for (const [type, list] of group(i.measurements, (m) => m.type)) {
    const sorted = [...list].sort((a, b) => a.localDate.localeCompare(b.localDate));
    const latest = sorted[sorted.length - 1];
    const older = sorted.find((m) => m.localDate <= i.weekStart) ?? (sorted.length > 1 ? sorted[0] : null);
    measurements.push({ type, latest: latest.value, change: older && older.id !== latest.id ? Math.round((latest.value - older.value) * 10) / 10 : null, unit: latest.unit });
  }
  if (measurements.length === 0) dataGaps.push('No body measurements recorded, so progress is judged from training only.');

  const achievements: string[] = [];
  const improvements: string[] = [];
  const recommendations: Recommendation[] = [];

  if (planned > 0 && completed === planned) achievements.push(`Completed all ${planned} planned sessions.`);
  else if (planned > 0 && completed + partial >= Math.ceil(planned * 0.75)) achievements.push(`Completed ${completed} of ${planned} sessions${partial ? ` plus ${partial} partial` : ''}.`);
  else if (planned > 0) {
    improvements.push(`${planned - completed - partial} planned session${planned - completed - partial === 1 ? '' : 's'} not started.`);
    recommendations.push({ id: 'adherence', title: 'Reschedule rather than stack', why: 'Missed sessions are easier to recover one at a time; the app can move them forward without doubling any day.', action: 'schedule' });
  }
  for (const s of strength.slice(0, 5)) {
    if (s.trend === 'up' && s.bestE1rm && s.prevE1rm) achievements.push(`${s.name}: estimated 1RM up from ${s.prevE1rm} to ${s.bestE1rm} kg (estimate).`);
    if (s.trend === 'down' && s.bestE1rm && s.prevE1rm) improvements.push(`${s.name}: estimated 1RM down from ${s.prevE1rm} to ${s.bestE1rm} kg; could be fatigue, sleep or a lighter week.`);
  }
  const highSoreness = (recovery.avgSoreness ?? 0) >= 3.5;
  const lowSleep = recovery.avgSleep != null && recovery.avgSleep < 6;
  const manyDown = strength.filter((s) => s.trend === 'down').length >= 2;
  if ((highSoreness || lowSleep) && manyDown) {
    recommendations.push({ id: 'deload', title: 'Take a lighter week', why: `Soreness ${recovery.avgSoreness ?? '-'} / 5, sleep ${recovery.avgSleep ?? '-'} h and ${strength.filter((s) => s.trend === 'down').length} lifts trending down: reduce sets by one on main lifts for a week, then resume.`, action: 'deload' });
  } else if (strength.some((s) => s.trend === 'up')) {
    recommendations.push({ id: 'progress', title: 'Keep the double-progression rule', why: 'Loads rise only when every set reaches the top of the rep range. Several lifts did that this week, so suggestions will increase where earned.', action: 'progress' });
  } else if (strength.length) {
    recommendations.push({ id: 'hold', title: 'Hold loads and chase reps', why: 'No lift reached the top of its range on every set; add reps before adding weight.', action: 'hold' });
  }
  if (hyd.daysLogged >= 4 && hyd.daysOnTarget < hyd.daysLogged / 2) {
    improvements.push(`Water target met on ${hyd.daysOnTarget} of ${hyd.daysLogged} logged days.`);
    recommendations.push({ id: 'water', title: 'Front-load water earlier in the day', why: 'Most shortfalls come from evenings; a reminder in the morning window helps more than one late.', action: 'habit' });
  } else if (hyd.daysLogged >= 4) achievements.push(`Water target met on ${hyd.daysOnTarget} of ${hyd.daysLogged} days.`);
  if (nutrition && nutrition.daysLogged >= 4) {
    achievements.push(`Nutrition logged on ${nutrition.daysLogged} days, averaging ${nutrition.avgKcal} kcal and ${nutrition.avgProtein} g protein.`);
  } else if (i.nutrition) dataGaps.push('Nutrition logged on fewer than four days, so intake averages are not reliable.');
  const weight = measurements.find((m) => m.type === 'weight');
  const waist = measurements.find((m) => m.type === 'waist');
  if (weight?.change != null && waist?.change != null) {
    achievements.push(`Weight ${fmtChange(weight.change)} kg and waist ${fmtChange(waist.change)} cm since the start of the week. Day-to-day weight swings with water and food; read it with the waist and strength trends.`);
  }

  const summary = planned === 0
    ? 'No sessions were planned this week.'
    : `${completed} of ${planned} planned sessions completed${partial ? `, ${partial} partial` : ''}. ${strength.filter((s) => s.trend === 'up').length} lifts trending up, ${strength.filter((s) => s.trend === 'down').length} down. ${recovery.days ? `Average sleep ${recovery.avgSleep ?? '-'} h, soreness ${recovery.avgSoreness ?? '-'}/5.` : 'No recovery check-ins.'}`;

  return { summary, adherence: { planned, completed, partial }, strength, recovery, hydration: hyd, nutrition, measurements, achievements, improvements, recommendations, dataGaps };
}

function bestE1(sets: SetLog[]): number | null {
  let best: number | null = null;
  for (const s of sets) { const v = estimateOneRm(s.weightKg, s.reps); if (v != null && (best == null || v > best)) best = v; }
  return best;
}

function group<T>(xs: T[], key: (x: T) => string): Map<string, T[]> {
  const m = new Map<string, T[]>();
  for (const x of xs) { const k = key(x); if (!m.has(k)) m.set(k, []); m.get(k)!.push(x); }
  return m;
}

function fmtChange(n: number): string {
  return n > 0 ? `+${n}` : `${n}`;
}

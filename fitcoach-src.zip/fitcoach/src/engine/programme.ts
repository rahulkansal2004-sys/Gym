// Deterministic programme generator. Produces a 12-week block of planned workouts from the
// user's profile and goal using established resistance-training principles: movement balance,
// frequency by available days, volume by experience, rep schemes by goal, equipment and restriction filters.
import type { Exercise, GoalId, PlannedExercise, PlannedWorkout, Profile, Programme } from '../db/types';
import type { Equipment, MovementPattern, Difficulty, MuscleGroup } from '../data/exercises';
import { addDays, isoWeekday, nowIso, uid } from '../lib/time';

export type Role = PlannedExercise['role'];

interface Slot {
  pattern: MovementPattern;
  role: Role;
  muscle?: MuscleGroup; // for isolation slots
  optional?: boolean;
}

export interface DayTemplate {
  name: string;
  focus: string;
  slots: Slot[];
}

const UPPER_A: Slot[] = [
  { pattern: 'horizontal-push', role: 'main' },
  { pattern: 'horizontal-pull', role: 'main' },
  { pattern: 'vertical-push', role: 'secondary' },
  { pattern: 'vertical-pull', role: 'secondary' },
  { pattern: 'isolation', role: 'accessory', muscle: 'biceps', optional: true },
  { pattern: 'isolation', role: 'accessory', muscle: 'triceps', optional: true },
];
const UPPER_B: Slot[] = [
  { pattern: 'vertical-push', role: 'main' },
  { pattern: 'vertical-pull', role: 'main' },
  { pattern: 'horizontal-push', role: 'secondary' },
  { pattern: 'horizontal-pull', role: 'secondary' },
  { pattern: 'isolation', role: 'accessory', muscle: 'shoulders', optional: true },
  { pattern: 'core', role: 'accessory', optional: true },
];
const LOWER_A: Slot[] = [
  { pattern: 'squat', role: 'main' },
  { pattern: 'hinge', role: 'secondary' },
  { pattern: 'lunge', role: 'secondary' },
  { pattern: 'isolation', role: 'accessory', muscle: 'calves', optional: true },
  { pattern: 'core', role: 'accessory', optional: true },
];
const LOWER_B: Slot[] = [
  { pattern: 'hinge', role: 'main' },
  { pattern: 'squat', role: 'secondary' },
  { pattern: 'isolation', role: 'accessory', muscle: 'hamstrings', optional: true },
  { pattern: 'isolation', role: 'accessory', muscle: 'glutes', optional: true },
  { pattern: 'carry', role: 'accessory', optional: true },
];
const FULL_A: Slot[] = [
  { pattern: 'squat', role: 'main' },
  { pattern: 'horizontal-push', role: 'main' },
  { pattern: 'horizontal-pull', role: 'secondary' },
  { pattern: 'core', role: 'accessory', optional: true },
];
const FULL_B: Slot[] = [
  { pattern: 'hinge', role: 'main' },
  { pattern: 'vertical-push', role: 'main' },
  { pattern: 'vertical-pull', role: 'secondary' },
  { pattern: 'lunge', role: 'accessory', optional: true },
];
const FULL_C: Slot[] = [
  { pattern: 'lunge', role: 'main' },
  { pattern: 'horizontal-push', role: 'secondary' },
  { pattern: 'horizontal-pull', role: 'secondary' },
  { pattern: 'carry', role: 'accessory', optional: true },
  { pattern: 'core', role: 'accessory', optional: true },
];
const PUSH: Slot[] = [
  { pattern: 'horizontal-push', role: 'main' },
  { pattern: 'vertical-push', role: 'secondary' },
  { pattern: 'horizontal-push', role: 'secondary' },
  { pattern: 'isolation', role: 'accessory', muscle: 'shoulders', optional: true },
  { pattern: 'isolation', role: 'accessory', muscle: 'triceps', optional: true },
];
const PULL: Slot[] = [
  { pattern: 'vertical-pull', role: 'main' },
  { pattern: 'horizontal-pull', role: 'secondary' },
  { pattern: 'horizontal-pull', role: 'secondary' },
  { pattern: 'isolation', role: 'accessory', muscle: 'biceps', optional: true },
  { pattern: 'isolation', role: 'accessory', muscle: 'back', optional: true },
];
const LEGS: Slot[] = [
  { pattern: 'squat', role: 'main' },
  { pattern: 'hinge', role: 'secondary' },
  { pattern: 'lunge', role: 'secondary' },
  { pattern: 'isolation', role: 'accessory', muscle: 'calves', optional: true },
  { pattern: 'core', role: 'accessory', optional: true },
];

export function templateFor(days: number): { id: string; name: string; days: DayTemplate[] } {
  switch (Math.min(6, Math.max(2, days))) {
    case 2:
      return { id: 'full-body-2', name: 'Full body, 2 days', days: [
        { name: 'Full body A', focus: 'Squat, push, pull', slots: FULL_A },
        { name: 'Full body B', focus: 'Hinge, press, pull', slots: FULL_B },
      ] };
    case 3:
      return { id: 'full-body-3', name: 'Full body, 3 days', days: [
        { name: 'Full body A', focus: 'Squat, push, pull', slots: FULL_A },
        { name: 'Full body B', focus: 'Hinge, press, pull', slots: FULL_B },
        { name: 'Full body C', focus: 'Lunge, push, pull, carry', slots: FULL_C },
      ] };
    case 4:
      return { id: 'upper-lower-4', name: 'Upper / lower, 4 days', days: [
        { name: 'Upper A', focus: 'Horizontal push and pull', slots: UPPER_A },
        { name: 'Lower A', focus: 'Squat focus', slots: LOWER_A },
        { name: 'Upper B', focus: 'Vertical push and pull', slots: UPPER_B },
        { name: 'Lower B', focus: 'Hinge focus', slots: LOWER_B },
      ] };
    case 5:
      return { id: 'hybrid-5', name: 'Upper / lower / push / pull / legs, 5 days', days: [
        { name: 'Upper', focus: 'Horizontal push and pull', slots: UPPER_A },
        { name: 'Lower', focus: 'Squat focus', slots: LOWER_A },
        { name: 'Push', focus: 'Chest, shoulders, triceps', slots: PUSH },
        { name: 'Pull', focus: 'Back and biceps', slots: PULL },
        { name: 'Legs and core', focus: 'Hinge focus', slots: LOWER_B },
      ] };
    default:
      return { id: 'ppl-6', name: 'Push / pull / legs, 6 days', days: [
        { name: 'Push A', focus: 'Chest, shoulders, triceps', slots: PUSH },
        { name: 'Pull A', focus: 'Back and biceps', slots: PULL },
        { name: 'Legs A', focus: 'Squat focus', slots: LEGS },
        { name: 'Push B', focus: 'Shoulders first', slots: UPPER_B.filter((s) => s.pattern !== 'vertical-pull' && s.pattern !== 'horizontal-pull') },
        { name: 'Pull B', focus: 'Rows first', slots: [PULL[1], PULL[0], PULL[2], PULL[3], PULL[4]] },
        { name: 'Legs B', focus: 'Hinge focus', slots: LOWER_B },
      ] };
  }
}

export interface Scheme { sets: number; repMin: number; repMax: number; rest: number }

/** Rep scheme by goal and role. */
export function schemeFor(goal: GoalId, role: Role, experience: Profile['experience']): Scheme {
  const table: Record<string, Record<Role, Scheme>> = {
    strength: {
      main: { sets: 4, repMin: 4, repMax: 6, rest: 150 }, secondary: { sets: 3, repMin: 6, repMax: 8, rest: 120 },
      accessory: { sets: 3, repMin: 8, repMax: 12, rest: 75 }, cardio: { sets: 1, repMin: 0, repMax: 0, rest: 0 }, mobility: { sets: 1, repMin: 0, repMax: 0, rest: 0 },
    },
    hypertrophy: {
      main: { sets: 3, repMin: 6, repMax: 10, rest: 120 }, secondary: { sets: 3, repMin: 8, repMax: 12, rest: 90 },
      accessory: { sets: 3, repMin: 10, repMax: 15, rest: 60 }, cardio: { sets: 1, repMin: 0, repMax: 0, rest: 0 }, mobility: { sets: 1, repMin: 0, repMax: 0, rest: 0 },
    },
    general: {
      main: { sets: 3, repMin: 8, repMax: 12, rest: 90 }, secondary: { sets: 3, repMin: 10, repMax: 12, rest: 75 },
      accessory: { sets: 2, repMin: 12, repMax: 15, rest: 60 }, cardio: { sets: 1, repMin: 0, repMax: 0, rest: 0 }, mobility: { sets: 1, repMin: 0, repMax: 0, rest: 0 },
    },
    endurance: {
      main: { sets: 3, repMin: 12, repMax: 15, rest: 60 }, secondary: { sets: 3, repMin: 12, repMax: 15, rest: 60 },
      accessory: { sets: 2, repMin: 15, repMax: 20, rest: 45 }, cardio: { sets: 1, repMin: 0, repMax: 0, rest: 0 }, mobility: { sets: 1, repMin: 0, repMax: 0, rest: 0 },
    },
    athletic: {
      main: { sets: 4, repMin: 5, repMax: 8, rest: 120 }, secondary: { sets: 3, repMin: 8, repMax: 10, rest: 90 },
      accessory: { sets: 3, repMin: 10, repMax: 12, rest: 60 }, cardio: { sets: 1, repMin: 0, repMax: 0, rest: 0 }, mobility: { sets: 1, repMin: 0, repMax: 0, rest: 0 },
    },
  };
  const family = goal === 'strength' ? 'strength'
    : goal === 'endurance' ? 'endurance'
    : goal === 'athletic' ? 'athletic'
    : goal === 'fat-loss' || goal === 'general-health' || goal === 'custom' ? 'general'
    : 'hypertrophy';
  const s = { ...table[family][role] };
  if ((experience === 'new' || experience === 'unsure') && role !== 'cardio' && role !== 'mobility') s.sets = Math.max(2, s.sets - 1);
  if (experience === 'advanced' && role === 'main') s.sets += 1;
  return s;
}

const FALLBACK_PATTERN: Partial<Record<MovementPattern, MovementPattern>> = {
  'vertical-pull': 'horizontal-pull', 'vertical-push': 'horizontal-push', 'horizontal-pull': 'vertical-pull',
  'horizontal-push': 'vertical-push', lunge: 'squat', hinge: 'squat', squat: 'lunge', carry: 'core',
};

const DIFF_RANK: Record<Difficulty, number> = { beginner: 0, intermediate: 1, advanced: 2 };
function maxDifficulty(exp: Profile['experience']): number {
  return exp === 'advanced' ? 2 : exp === 'intermediate' ? 1 : 0;
}

export function equipmentAvailable(ex: Exercise, available: Equipment[]): boolean {
  const have = new Set<Equipment>([...available, 'bodyweight']);
  return ex.equipment.every((e) => have.has(e));
}

export function isAllowed(ex: Exercise, profile: Profile): boolean {
  if (!equipmentAvailable(ex, profile.equipment)) return false;
  if (DIFF_RANK[ex.difficulty] > maxDifficulty(profile.experience)) return false;
  if (ex.contraindications.some((c) => profile.restrictions.includes(c))) return false;
  if (profile.excludeGluteIsolation && ex.isGluteIsolation) return false;
  return true;
}

function pickForSlot(slot: Slot, pool: Exercise[], profile: Profile, used: Set<string>, weekUsed: Map<string, number>): Exercise | null {
  let cands = pool.filter((e) => e.movementPattern === slot.pattern && isAllowed(e, profile));
  if (slot.muscle) cands = cands.filter((e) => e.primaryMuscles.includes(slot.muscle!));
  if (slot.pattern === 'isolation' && !slot.muscle) cands = [];
  if (cands.length === 0) {
    // relax difficulty one notch for compounds so a day is never empty
    cands = pool.filter((e) => e.movementPattern === slot.pattern && equipmentAvailable(e, profile.equipment)
      && !e.contraindications.some((c) => profile.restrictions.includes(c)) && !(profile.excludeGluteIsolation && e.isGluteIsolation)
      && (!slot.muscle || e.primaryMuscles.includes(slot.muscle)));
  }
  if (cands.length === 0) return null;
  const score = (e: Exercise) => {
    let s = 0;
    if (used.has(e.id)) s += 100; // not twice in one day
    s += (weekUsed.get(e.id) ?? 0) * 10; // spread across the week
    if (slot.role === 'main' && e.category === 'compound') s -= 5;
    if (slot.role === 'main' && e.equipment.includes('barbell')) s -= 2;
    if (slot.role === 'main' && e.equipment.includes('machine')) s += 1;
    if (e.equipment.includes('band') && profile.equipment.some((q) => q !== 'band' && q !== 'bodyweight')) s += 3; // prefer free weights/cables when available
    s += Math.abs(DIFF_RANK[e.difficulty] - Math.min(maxDifficulty(profile.experience), 1));
    return s;
  };
  cands.sort((a, b) => score(a) - score(b) || a.id.localeCompare(b.id));
  return cands[0];
}

export function estimateMinutes(exs: PlannedExercise[]): number {
  let s = 6 * 60; // warm-up
  for (const e of exs) {
    if (e.durationMinutes) s += e.durationMinutes * 60;
    else s += e.sets * (40 + e.restSeconds);
  }
  return Math.round(s / 60);
}

export const TRAINING_WEEKDAYS: Record<number, number[]> = {
  2: [1, 4], 3: [1, 3, 5], 4: [1, 2, 4, 5], 5: [1, 2, 3, 5, 6], 6: [1, 2, 3, 4, 5, 6],
};

export interface GenerateOptions {
  profile: Profile;
  goal: GoalId;
  exercises: Exercise[];
  startDate: string; // YYYY-MM-DD
  weeks?: number;
  trainingWeekdays?: number[];
}

export interface GenerateResult {
  programme: Programme;
  workouts: PlannedWorkout[];
  warnings: string[];
}

export function generateProgramme(opts: GenerateOptions): GenerateResult {
  const { profile, goal, exercises } = opts;
  const weeks = opts.weeks ?? 12;
  const days = Math.min(6, Math.max(2, profile.daysPerWeek));
  const warnings: string[] = [];
  if (days === 6 && (profile.experience === 'new' || profile.experience === 'unsure' || profile.experience === 'beginner-some')) {
    warnings.push('Six days a week is a lot for a newer lifter. The plan is built, but four days usually gives better recovery and the same progress.');
  }
  const tpl = templateFor(days);
  const weekdays = (opts.trainingWeekdays ?? TRAINING_WEEKDAYS[days]).slice(0, days);
  const cardioGoal = goal === 'fat-loss' || goal === 'endurance' || goal === 'general-health' || goal === 'lean' || goal === 'athletic';
  const cardio = exercises.filter((e) => e.category === 'cardio' && isAllowed(e, profile));
  const mobility = exercises.filter((e) => e.category === 'mobility' && isAllowed(e, profile));

  // Build the base week once (exercise selection), then repeat it with weekly progression markers.
  const weekUsed = new Map<string, number>();
  const baseDays: { tpl: DayTemplate; exercises: PlannedExercise[] }[] = [];
  for (const day of tpl.days) {
    const used = new Set<string>();
    const chosen: PlannedExercise[] = [];
    for (const slot of day.slots) {
      let ex = pickForSlot(slot, exercises, profile, used, weekUsed);
      if (!ex && FALLBACK_PATTERN[slot.pattern]) {
        ex = pickForSlot({ ...slot, pattern: FALLBACK_PATTERN[slot.pattern]! }, exercises, profile, used, weekUsed);
        if (ex && !slot.optional) warnings.push(`No ${slot.pattern.replace('-', ' ')} exercise fits your equipment, so ${day.name} uses ${ex.name} instead (a pull-up bar or band would add vertical pulling).`);
      }
      if (!ex) {
        if (!slot.optional) warnings.push(`No ${slot.pattern} exercise fits your equipment and restrictions for ${day.name}; add equipment or adjust restrictions.`);
        continue;
      }
      used.add(ex.id);
      weekUsed.set(ex.id, (weekUsed.get(ex.id) ?? 0) + 1);
      const sc = schemeFor(goal, slot.role, profile.experience);
      const isTimed = ex.repRange[0] === 0 && ex.repRange[1] === 0;
      chosen.push({
        exerciseId: ex.id, role: slot.role, sets: isTimed ? Math.min(sc.sets, 3) : sc.sets,
        repMin: isTimed ? 0 : sc.repMin, repMax: isTimed ? 0 : sc.repMax, restSeconds: isTimed ? Math.min(60, ex.restSeconds) : sc.rest,
        durationMinutes: isTimed ? ex.durationMinutes ?? 1 : undefined, suggestedKg: null,
      });
    }
    if (cardioGoal && cardio.length) {
      const c = cardio[baseDays.length % cardio.length];
      const minutes = goal === 'endurance' ? 25 : 15;
      chosen.push({ exerciseId: c.id, role: 'cardio', sets: 1, repMin: 0, repMax: 0, restSeconds: 0, durationMinutes: minutes, suggestedKg: null });
    }
    if (mobility.length) {
      const m = mobility[baseDays.length % mobility.length];
      chosen.push({ exerciseId: m.id, role: 'mobility', sets: 1, repMin: 0, repMax: 0, restSeconds: 0, durationMinutes: 3, suggestedKg: null });
    }
    // Fit the session into the preferred duration: drop optional accessories, then cardio minutes, then a secondary set.
    let fitted = chosen;
    const limit = profile.sessionMinutes + 5;
    while (estimateMinutes(fitted) > limit) {
      const accIdx = fitted.map((e, i) => (e.role === 'accessory' ? i : -1)).filter((i) => i >= 0).pop();
      if (accIdx !== undefined) { fitted = fitted.filter((_, i) => i !== accIdx); continue; }
      const cIdx = fitted.findIndex((e) => e.role === 'cardio' && (e.durationMinutes ?? 0) > 10);
      if (cIdx >= 0) { fitted = fitted.map((e, i) => (i === cIdx ? { ...e, durationMinutes: (e.durationMinutes ?? 0) - 5 } : e)); continue; }
      const sIdx = fitted.findIndex((e) => e.role === 'secondary' && e.sets > 2);
      if (sIdx >= 0) { fitted = fitted.map((e, i) => (i === sIdx ? { ...e, sets: e.sets - 1 } : e)); continue; }
      break;
    }
    baseDays.push({ tpl: day, exercises: fitted });
  }

  const programme: Programme = {
    id: uid(), name: `${tpl.name} · ${goalLabel(goal)}`, template: tpl.id, goal, daysPerWeek: days, weeks,
    startDate: opts.startDate, status: 'active',
    config: { trainingWeekdays: weekdays, deloadWeeks: deloadWeeks(weeks), experience: profile.experience, sessionMinutes: profile.sessionMinutes },
    createdAt: nowIso(),
  };

  // Schedule: iterate calendar days from startDate, assign each training weekday the next day template.
  const workouts: PlannedWorkout[] = [];
  let date = opts.startDate;
  let dayCounter = 0;
  const totalSessions = weeks * days;
  let guard = 0;
  while (workouts.length < totalSessions && guard++ < weeks * 7 + 14) {
    if (weekdays.includes(isoWeekday(date))) {
      const week = Math.floor(dayCounter / days) + 1;
      const dayIndex = dayCounter % days;
      const base = baseDays[dayIndex];
      const deload = (programme.config.deloadWeeks as number[]).includes(week);
      const exs = base.exercises.map((e) => ({ ...e, sets: deload && e.sets > 2 ? e.sets - 1 : e.sets }));
      workouts.push({
        id: uid(), programmeId: programme.id, week, dayIndex, scheduledDate: date,
        name: base.tpl.name + (deload ? ' (lighter week)' : ''), focus: base.tpl.focus, exercises: exs, status: 'planned',
        estimatedMinutes: estimateMinutes(exs),
      });
      dayCounter++;
    }
    date = addDays(date, 1);
  }
  return { programme, workouts, warnings };
}

export function deloadWeeks(weeks: number): number[] {
  const out: number[] = [];
  for (let w = 4; w <= weeks; w += 4) out.push(w);
  return out;
}

export const GOAL_INFO: Record<GoalId, { label: string; blurb: string }> = {
  lean: { label: 'Lean and defined', blurb: 'Resistance training, regular aerobic work and sustainable nutrition.' },
  muscular: { label: 'Muscular and bulky', blurb: 'Progressive resistance training with enough food and recovery to grow.' },
  athletic: { label: 'Athletic and performance-focused', blurb: 'Strength, conditioning, mobility and endurance in balance.' },
  toned: { label: 'Fit and toned', blurb: 'Balanced, approachable training for a strong, healthy physique.' },
  'fat-loss': { label: 'Fat loss and weight management', blurb: 'Sustainable activity plus resistance training, with optional nutrition guidance.' },
  'muscle-gain': { label: 'Muscle gain', blurb: 'Hypertrophy-focused volume with progressive overload and adequate protein.' },
  strength: { label: 'Strength development', blurb: 'Heavier, measurable strength work with longer rests.' },
  endurance: { label: 'Endurance and stamina', blurb: 'Progressively structured cardio with supporting strength work.' },
  'general-health': { label: 'General health and beginner fitness', blurb: 'Accessible, balanced exercise and habit building.' },
  custom: { label: 'Custom goal', blurb: 'Tell the app what you are training for in your own words.' },
};

export function goalLabel(g: GoalId): string {
  return GOAL_INFO[g]?.label ?? g;
}

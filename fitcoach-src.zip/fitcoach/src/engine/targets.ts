import type { GoalId, Profile } from '../db/types';

/** Mifflin–St Jeor resting energy, activity multiplier, goal adjustment. General guidance only. */
export function calorieTarget(p: Profile, goal: GoalId): { kcal: number; protein: number; carbs: number; fat: number; fibre: number; note: string } | null {
  if (!p.weightKg || !p.heightCm || !p.dob) return null;
  const age = Math.max(16, Math.floor((Date.now() - new Date(p.dob).getTime()) / (365.25 * 86400000)));
  const sexAdj = p.sex === 'female' ? -161 : p.sex === 'male' ? 5 : -78;
  const bmr = 10 * p.weightKg + 6.25 * p.heightCm - 5 * age + sexAdj;
  const mult = { sedentary: 1.2, light: 1.375, moderate: 1.55, active: 1.725, 'very-active': 1.9 }[p.activityLevel];
  const tdee = bmr * mult;
  let adj = 0;
  if (goal === 'fat-loss' || goal === 'lean') adj = -0.15;
  if (goal === 'muscular' || goal === 'muscle-gain') adj = 0.1;
  const kcal = Math.round(Math.max(1400, tdee * (1 + adj)) / 10) * 10;
  const protein = Math.round(p.weightKg * (goal === 'fat-loss' || goal === 'lean' || goal === 'muscular' || goal === 'muscle-gain' || goal === 'strength' ? 1.8 : 1.4));
  const fat = Math.round((kcal * 0.27) / 9);
  const carbs = Math.round((kcal - protein * 4 - fat * 9) / 4);
  return {
    kcal, protein, carbs, fat, fibre: 30,
    note: `Estimated from height, weight, age${p.sex && p.sex !== 'unspecified' ? ', sex' : ''} and activity level${adj ? ` with a modest ${adj > 0 ? 'surplus' : 'deficit'} for your goal` : ''}. A starting point, not a prescription.`,
  };
}

/** Starting hydration estimate: ~35 ml per kg, capped to a sensible band. User can override. */
export function hydrationTargetMl(p: Profile): { ml: number; note: string } {
  const base = p.weightKg ? p.weightKg * 35 : 2500;
  const ml = Math.round(Math.min(3500, Math.max(1800, base)) / 50) * 50;
  return { ml, note: 'About 35 ml per kg of body weight, capped between 1.8 and 3.5 L. Adjust for heat and training, and follow any limit your clinician has set.' };
}

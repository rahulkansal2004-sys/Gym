// Smart rescheduling and time-constrained workouts. Pure functions over planned workouts.
import type { PlannedExercise, PlannedWorkout } from '../db/types';
import { addDays, isoWeekday } from '../lib/time';
import { estimateMinutes } from './programme';

export interface ReschedulePlan {
  description: string;
  changes: { id: string; from: string; to: string; name: string }[];
  skipped: { id: string; name: string }[];
  substantial: boolean; // ask for confirmation
}

/** Planned workouts scheduled before `today` and never completed. */
export function missedWorkouts(workouts: PlannedWorkout[], today: string): PlannedWorkout[] {
  return workouts.filter((w) => w.scheduledDate < today && (w.status === 'planned' || w.status === 'rescheduled'));
}

/**
 * Push the missed sessions forward onto the next training days, shifting everything after them
 * so no day carries two sessions and the muscle-group order of the split is preserved.
 */
export function rescheduleForward(workouts: PlannedWorkout[], trainingWeekdays: number[], today: string): ReschedulePlan {
  const missed = missedWorkouts(workouts, today);
  if (missed.length === 0) return { description: 'Nothing to reschedule.', changes: [], skipped: [], substantial: false };
  const remaining = workouts
    .filter((w) => w.status === 'planned' || w.status === 'rescheduled' || w.status === 'partial')
    .sort((a, b) => a.scheduledDate.localeCompare(b.scheduledDate) || a.dayIndex - b.dayIndex);
  const changes: ReschedulePlan['changes'] = [];
  let date = today;
  for (const w of remaining) {
    while (!trainingWeekdays.includes(isoWeekday(date))) date = addDays(date, 1);
    if (w.scheduledDate !== date) changes.push({ id: w.id, from: w.scheduledDate, to: date, name: w.name });
    date = addDays(date, 1);
  }
  const weeksShift = Math.round(missed.length / Math.max(1, trainingWeekdays.length) * 10) / 10;
  return {
    description: `${missed.length} missed session${missed.length > 1 ? 's' : ''} moved to your next training days; everything after shifts by about ${weeksShift} week${weeksShift === 1 ? '' : 's'}. Nothing is doubled up.`,
    changes, skipped: [], substantial: missed.length >= 2,
  };
}

/** Skip the missed sessions and keep the calendar as planned. */
export function skipMissed(workouts: PlannedWorkout[], today: string): ReschedulePlan {
  const missed = missedWorkouts(workouts, today);
  return {
    description: `${missed.length} missed session${missed.length > 1 ? 's' : ''} marked as skipped; the rest of the plan stays on its dates. The muscle groups involved will be trained again in the next cycle.`,
    changes: [], skipped: missed.map((w) => ({ id: w.id, name: w.name })), substantial: false,
  };
}

/** Move missed sessions to the end of the block (after the last scheduled session). */
export function deferToEnd(workouts: PlannedWorkout[], trainingWeekdays: number[], today: string): ReschedulePlan {
  const missed = missedWorkouts(workouts, today);
  const future = workouts.filter((w) => w.scheduledDate >= today).map((w) => w.scheduledDate).sort();
  let date = addDays(future.length ? future[future.length - 1] : today, 1);
  const changes: ReschedulePlan['changes'] = [];
  for (const w of missed) {
    while (!trainingWeekdays.includes(isoWeekday(date))) date = addDays(date, 1);
    changes.push({ id: w.id, from: w.scheduledDate, to: date, name: w.name });
    date = addDays(date, 1);
  }
  return { description: `${missed.length} missed session${missed.length > 1 ? 's' : ''} appended to the end of this block.`, changes, skipped: [], substantial: false };
}

export interface ShortenResult {
  exercises: PlannedExercise[];
  removed: string[];
  reducedSets: string[];
  minutes: number;
}

/**
 * Fit a workout into fewer minutes. Order of cuts: accessories, cardio minutes, one set from
 * secondary lifts, one set from main lifts. The warm-up allowance and main movements are never removed.
 */
export function shortenWorkout(exs: PlannedExercise[], targetMinutes: number, names: (id: string) => string): ShortenResult {
  let cur = exs.map((e) => ({ ...e }));
  const removed: string[] = [];
  const reducedSets: string[] = [];
  let guard = 0;
  while (estimateMinutes(cur) > targetMinutes && guard++ < 40) {
    const acc = cur.map((e, i) => (e.role === 'accessory' || e.role === 'mobility' ? i : -1)).filter((i) => i >= 0).pop();
    if (acc !== undefined) { removed.push(names(cur[acc].exerciseId)); cur = cur.filter((_, i) => i !== acc); continue; }
    const c = cur.findIndex((e) => e.role === 'cardio' && (e.durationMinutes ?? 0) > 8);
    if (c >= 0) { cur[c].durationMinutes = (cur[c].durationMinutes ?? 0) - 5; reducedSets.push(`${names(cur[c].exerciseId)} shortened`); continue; }
    const s = cur.findIndex((e) => e.role === 'secondary' && e.sets > 2);
    if (s >= 0) { cur[s].sets -= 1; reducedSets.push(`${names(cur[s].exerciseId)} −1 set`); continue; }
    const m = cur.findIndex((e) => e.role === 'main' && e.sets > 2);
    if (m >= 0) { cur[m].sets -= 1; reducedSets.push(`${names(cur[m].exerciseId)} −1 set`); continue; }
    break;
  }
  return { exercises: cur, removed, reducedSets, minutes: estimateMinutes(cur) };
}

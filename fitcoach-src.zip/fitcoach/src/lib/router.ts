import { useEffect, useState } from 'react';

/** Minimal hash router: "#/path/with/segments". */
export function currentPath(): string {
  const h = window.location.hash.replace(/^#/, '');
  return h.startsWith('/') ? h : '/' + h;
}

export function navigate(path: string, replace = false): void {
  if (replace) window.location.replace('#' + path);
  else window.location.hash = path;
}

export function back(fallback = '/'): void {
  if (window.history.length > 1) window.history.back();
  else navigate(fallback, true);
}

export function useRoute(): { path: string; segments: string[]; query: URLSearchParams } {
  const [path, setPath] = useState(currentPath());
  useEffect(() => {
    const on = () => setPath(currentPath());
    window.addEventListener('hashchange', on);
    return () => window.removeEventListener('hashchange', on);
  }, []);
  const [p, q] = path.split('?');
  return { path: p, segments: p.split('/').filter(Boolean), query: new URLSearchParams(q ?? '') };
}

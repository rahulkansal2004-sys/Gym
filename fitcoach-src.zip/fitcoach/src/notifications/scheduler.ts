// Applies planned occurrences to the device with @capacitor/local-notifications.
// Nothing is reported as "active" unless permission is granted and scheduling succeeded.
import { LocalNotifications, type LocalNotificationSchema } from '@capacitor/local-notifications';
import { Capacitor } from '@capacitor/core';
import { listReminders, getSetting, setSetting } from '../db/repos';
import { planOccurrences, toCapWeekday, stableId, type QuietHours } from './planner';

export interface NotificationStatus {
  supported: boolean;
  permission: 'granted' | 'denied' | 'prompt' | 'unknown';
  scheduled: number;
  lastError: string | null;
  exactAlarms: boolean | null;
}

export async function getQuietHours(): Promise<QuietHours> {
  const raw = await getSetting('quiet_hours');
  return raw ? (JSON.parse(raw) as QuietHours) : { enabled: true, start: '22:00', end: '07:00' };
}

export async function setQuietHours(q: QuietHours): Promise<void> {
  await setSetting('quiet_hours', JSON.stringify(q));
}

export async function getAllOff(): Promise<boolean> {
  return (await getSetting('reminders_all_off')) === '1';
}

export async function setAllOff(v: boolean): Promise<void> {
  await setSetting('reminders_all_off', v ? '1' : '0');
}

export function notificationsSupported(): boolean {
  return Capacitor.isNativePlatform();
}

export async function requestPermission(): Promise<NotificationStatus['permission']> {
  if (!notificationsSupported()) return 'unknown';
  const r = await LocalNotifications.requestPermissions();
  return r.display === 'granted' ? 'granted' : r.display === 'denied' ? 'denied' : 'prompt';
}

export async function getStatus(): Promise<NotificationStatus> {
  if (!notificationsSupported()) return { supported: false, permission: 'unknown', scheduled: 0, lastError: 'Notifications are only available in the Android app, not the browser preview.', exactAlarms: null };
  try {
    const p = await LocalNotifications.checkPermissions();
    const pending = await LocalNotifications.getPending();
    let exact: boolean | null = null;
    try { exact = (await LocalNotifications.checkExactNotificationSetting()).exact_alarm === 'granted'; } catch { exact = null; }
    return {
      supported: true, permission: p.display === 'granted' ? 'granted' : p.display === 'denied' ? 'denied' : 'prompt',
      scheduled: pending.notifications.length, lastError: (await getSetting('notif_last_error')) || null, exactAlarms: exact,
    };
  } catch (e) {
    return { supported: true, permission: 'unknown', scheduled: 0, lastError: (e as Error).message, exactAlarms: null };
  }
}

/** Re-plan everything from the saved reminder settings. Cancels stale notifications first. */
export async function syncSchedule(): Promise<NotificationStatus> {
  if (!notificationsSupported()) return getStatus();
  try {
    const perm = await LocalNotifications.checkPermissions();
    if (perm.display !== 'granted') {
      await setSetting('notif_last_error', 'Notification permission not granted');
      return getStatus();
    }
    await LocalNotifications.createChannel({ id: 'fitcoach-reminders', name: 'Reminders', description: 'Workout, water, meal and review reminders', importance: 3, visibility: 1 });
    const reminders = await listReminders();
    const occurrences = planOccurrences(reminders, await getQuietHours(), await getAllOff());
    const pending = await LocalNotifications.getPending();
    const keep = new Set(occurrences.map((o) => o.id));
    const stale = pending.notifications.filter((n) => !keep.has(n.id) && n.extra?.kind !== 'snooze');
    if (stale.length) await LocalNotifications.cancel({ notifications: stale.map((n) => ({ id: n.id })) });
    const existing = new Set(pending.notifications.map((n) => n.id));
    const fresh = occurrences.filter((o) => !existing.has(o.id));
    if (fresh.length) {
      const notifications: LocalNotificationSchema[] = fresh.map((o) => ({
        id: o.id, title: o.title, body: o.body, channelId: 'fitcoach-reminders', extra: { kind: 'reminder', reminderId: o.reminderId },
        isExactNotification: false,
        schedule: { on: { weekday: toCapWeekday(o.weekday), hour: o.hour, minute: o.minute }, allowWhileIdle: true },
      }));
      await LocalNotifications.schedule({ notifications });
    }
    await setSetting('notif_last_error', '');
  } catch (e) {
    await setSetting('notif_last_error', (e as Error).message);
  }
  return getStatus();
}

export async function snooze(reminderId: string, minutes: number, title: string, body: string): Promise<void> {
  if (!notificationsSupported()) return;
  const at = new Date(Date.now() + minutes * 60000);
  await LocalNotifications.schedule({ notifications: [{
    id: stableId(`snooze|${reminderId}`), title, body, channelId: 'fitcoach-reminders', extra: { kind: 'snooze', reminderId },
    isExactNotification: false, schedule: { at, allowWhileIdle: true },
  }] });
}

export async function cancelAll(): Promise<void> {
  if (!notificationsSupported()) return;
  const pending = await LocalNotifications.getPending();
  if (pending.notifications.length) await LocalNotifications.cancel({ notifications: pending.notifications.map((n) => ({ id: n.id })) });
}

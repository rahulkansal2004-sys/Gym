// Coaching tasks: build privacy-minimised prompts from derived data, call Gemini, and fall back to
// deterministic text when the AI is off, offline, out of quota or returns nothing.
import { askGemini, type AiResult } from './gemini';
import type { WeeklyReview } from '../engine/review';
import type { Exercise, Profile, Goal } from '../db/types';
import { GOAL_INFO } from '../engine/programme';

export interface CoachAnswer {
  text: string;
  source: 'ai' | 'fallback';
  note: string | null; // why fallback was used, if so
}

function fallbackNote(r: AiResult): string | null {
  return r.ok ? null : r.message;
}

/** Only non-identifying context: goal, experience, equipment summary. Never name, DOB, exact body measurements. */
function profileContext(p: Profile, g: Goal | null): string {
  return [
    `Goal: ${g ? GOAL_INFO[g.primaryGoal].label : 'not set'}${g?.secondaryGoal ? ` (secondary: ${GOAL_INFO[g.secondaryGoal].label})` : ''}`,
    `Experience: ${p.experience}. Trains ${p.daysPerWeek} days/week, ${p.sessionMinutes} min sessions, ${p.location}.`,
    `Equipment: ${p.equipment.join(', ')}. Diet: ${p.diet}.`,
    p.restrictions.length ? `Reported restrictions (avoid loading): ${p.restrictions.join(', ')}.` : 'No reported restrictions.',
  ].join('\n');
}

export async function weeklyReviewNarrative(review: WeeklyReview, p: Profile, g: Goal | null): Promise<CoachAnswer> {
  const evidence = JSON.stringify({
    summary: review.summary, adherence: review.adherence, strength: review.strength.slice(0, 6), recovery: review.recovery,
    hydration: review.hydration, nutrition: review.nutrition, measurements: review.measurements, dataGaps: review.dataGaps,
    engineRecommendations: review.recommendations,
  });
  const r = await askGemini({
    kind: 'weekly-review',
    system: `Write a weekly coaching review in 4 short paragraphs: progress summary with the evidence, achievements, areas to improve, and the engine's recommendations explained in plain words (do not add new load changes). Mention data gaps honestly.\n${profileContext(p, g)}`,
    user: `Recorded data for the week (JSON):\n${evidence}`,
    maxOutputTokens: 900,
  });
  if (r.ok) return { text: r.text, source: 'ai', note: null };
  return { text: deterministicReviewText(review), source: 'fallback', note: fallbackNote(r) };
}

export function deterministicReviewText(review: WeeklyReview): string {
  const lines = [review.summary, ''];
  if (review.achievements.length) lines.push('What went well:', ...review.achievements.map((a) => '• ' + a), '');
  if (review.improvements.length) lines.push('Worth attention:', ...review.improvements.map((a) => '• ' + a), '');
  if (review.recommendations.length) lines.push('Recommendations:', ...review.recommendations.map((r) => `• ${r.title}: ${r.why}`), '');
  if (review.dataGaps.length) lines.push('Data gaps:', ...review.dataGaps.map((a) => '• ' + a), '');
  lines.push('General fitness guidance, not medical advice.');
  return lines.join('\n');
}

export async function explainExercise(ex: Exercise, question: string | null): Promise<CoachAnswer> {
  const r = await askGemini({
    kind: 'explain',
    system: 'Explain the exercise using the provided instructions. You may add coaching cues consistent with them. Keep it under 180 words.',
    user: `Exercise: ${ex.name}\nSetup: ${ex.setup.join(' ')}\nExecution: ${ex.execution.join(' ')}\nBreathing: ${ex.breathing}\nCommon mistakes: ${ex.mistakes.join('; ')}\nSafety: ${ex.safety.join('; ')}\n${question ? `User question: ${question}` : 'Give the key cues.'}`,
    maxOutputTokens: 400,
  });
  if (r.ok) return { text: r.text, source: 'ai', note: null };
  return {
    text: `${ex.name}\n\nSetup: ${ex.setup.join(' ')}\n\nHow to do it: ${ex.execution.join(' ')}\n\nBreathing: ${ex.breathing}\n\nWatch out for: ${ex.mistakes.join('; ')}.\n\nSafety: ${ex.safety.join(' ')}`,
    source: 'fallback', note: fallbackNote(r),
  };
}

export async function sessionSummary(summary: Record<string, unknown>, p: Profile, g: Goal | null): Promise<CoachAnswer> {
  const r = await askGemini({
    kind: 'summary',
    system: `Summarise this workout in 3–4 sentences using only the numbers given, note any personal records, and give one specific, safe cue for next time.\n${profileContext(p, g)}`,
    user: JSON.stringify(summary),
    maxOutputTokens: 300,
  });
  if (r.ok) return { text: r.text, source: 'ai', note: null };
  return { text: '', source: 'fallback', note: fallbackNote(r) };
}

export async function chat(question: string, context: Record<string, unknown>, p: Profile, g: Goal | null): Promise<CoachAnswer> {
  const r = await askGemini({
    kind: 'chat',
    system: `Answer the user's fitness question. Use the context for facts about their recent training; do not invent data.\n${profileContext(p, g)}`,
    user: `Context (JSON): ${JSON.stringify(context)}\n\nQuestion: ${question}`,
    maxOutputTokens: 500,
  });
  if (r.ok) return { text: r.text, source: 'ai', note: null };
  return { text: 'The AI coach is unavailable right now. Your workouts, logs and progress are all still available offline.', source: 'fallback', note: fallbackNote(r) };
}

export async function analyseImprovementRequest(title: string, body: string): Promise<CoachAnswer> {
  const r = await askGemini({
    kind: 'improve-request',
    system: 'You are a product analyst for a personal fitness app (React + Capacitor + SQLite, offline-first). Analyse the request: category (feature/bug/usability), possible conflicts with existing features (workouts, nutrition, hydration, measurements, reminders, AI coach, wearables), a proposed change in 3–5 bullet points, estimated impact (small/medium/large) and what tests would be needed. State clearly that this is a proposal; no code is changed automatically.',
    user: `Title: ${title}\n\n${body}`,
    maxOutputTokens: 500,
  });
  if (r.ok) return { text: r.text, source: 'ai', note: null };
  return { text: 'Saved. AI analysis will run when the coach is online; the request is tracked here regardless.', source: 'fallback', note: fallbackNote(r) };
}

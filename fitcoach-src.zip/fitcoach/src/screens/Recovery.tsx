import { useEffect, useState } from 'react';
import { useApp } from '../app/store';
import * as repo from '../db/repos';
import type { RecoveryEntry } from '../db/types';
import { TopBar } from '../components/ui';
import { addDays, localDate } from '../lib/time';

const SCALES: { key: keyof Pick<RecoveryEntry, 'sleepQuality' | 'energy' | 'soreness' | 'recovery' | 'stress' | 'readiness'>; label: string; low: string; high: string }[] = [
  { key: 'sleepQuality', label: 'Sleep quality', low: 'poor', high: 'great' },
  { key: 'energy', label: 'Energy', low: 'drained', high: 'full' },
  { key: 'soreness', label: 'Muscle soreness', low: 'none', high: 'severe' },
  { key: 'recovery', label: 'Perceived recovery', low: 'not recovered', high: 'fully' },
  { key: 'stress', label: 'Stress (optional)', low: 'calm', high: 'very stressed' },
  { key: 'readiness', label: 'Workout readiness', low: 'rest day', high: 'ready to go' },
];

export function Recovery() {
  const { toast } = useApp();
  const today = localDate();
  const [e, setE] = useState<Omit<RecoveryEntry, 'id' | 'loggedAt'>>({ localDate: today, sleepHours: null, sleepQuality: null, energy: null, soreness: null, recovery: null, stress: null, readiness: null, source: 'manual' });
  const [history, setHistory] = useState<RecoveryEntry[]>([]);

  const reload = async () => {
    const list = await repo.listRecovery(addDays(today, -13), today);
    setHistory(list);
    const t = list.find((x) => x.localDate === today && x.source === 'manual');
    if (t) setE({ ...t });
  };
  useEffect(() => { void reload(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  async function save() {
    await repo.upsertRecovery(e);
    await reload();
    toast('Recovery check-in saved');
  }

  const avg = (k: keyof RecoveryEntry) => { const v = history.map((h) => h[k]).filter((x): x is number => typeof x === 'number'); return v.length ? (v.reduce((a, b) => a + b, 0) / v.length).toFixed(1) : '—'; };
  const readinessHint = e.readiness != null && e.readiness <= 2
    ? 'Low readiness: consider a lighter session, a walk, or rest. The programme engine never pushes harder on a low-readiness day.'
    : e.soreness != null && e.soreness >= 4 ? 'High soreness: keep today light and avoid loading the sore muscles heavily.' : null;

  return (
    <div className="screen">
      <TopBar title="Sleep and recovery" backTo="/" sub="Manual check-in · used as a conservative signal, never a diagnosis" />
      <div className="card">
        <div className="field"><label htmlFor="sh">Sleep last night (hours)</label><input id="sh" className="input" type="number" inputMode="decimal" step="0.5" value={e.sleepHours ?? ''} onChange={(x) => setE({ ...e, sleepHours: x.target.value ? Number(x.target.value) : null })} /></div>
        {SCALES.map((s) => (
          <fieldset key={s.key} style={{ border: 0, padding: 0, margin: 0 }} className="field">
            <legend style={{ padding: 0, fontSize: 13, fontWeight: 600, marginBottom: 4 }}>{s.label} <span className="tiny muted" style={{ fontWeight: 400 }}>1 {s.low} – 5 {s.high}</span></legend>
            <div className="grid5">{[1, 2, 3, 4, 5].map((v) => <button key={v} className={'choice' + (e[s.key] === v ? ' on' : '')} style={{ minHeight: 40 }} aria-pressed={e[s.key] === v} onClick={() => setE({ ...e, [s.key]: e[s.key] === v ? null : v })}>{v}</button>)}</div>
          </fieldset>
        ))}
        {readinessHint && <div className="card soft small">{readinessHint}</div>}
        <button className="btn md" onClick={save}>Save today's check-in</button>
      </div>
      <div className="card">
        <b>Last 14 days</b>
        <div className="grid3">
          <div className="stat"><b>{avg('sleepHours')}</b><span className="tiny muted">avg sleep h</span></div>
          <div className="stat"><b>{avg('soreness')}</b><span className="tiny muted">avg soreness</span></div>
          <div className="stat"><b>{avg('readiness')}</b><span className="tiny muted">avg readiness</span></div>
        </div>
        {history.length === 0 && <span className="small muted">No check-ins yet.</span>}
        {history.map((h) => <div key={h.id} className="row small"><span className="grow muted">{h.localDate}</span><span>{h.sleepHours != null ? `${h.sleepHours} h` : '—'}</span><span>sore {h.soreness ?? '—'}</span><span>ready {h.readiness ?? '—'}</span><span className="pill grey" style={{ fontSize: 10 }}>{h.source}</span></div>)}
        <span className="tiny muted">Sleep from Health Connect is not available through this app's plugin, so sleep is manual for now. Consumer-device sleep estimates, where added later, are not clinically accurate.</span>
      </div>
    </div>
  );
}

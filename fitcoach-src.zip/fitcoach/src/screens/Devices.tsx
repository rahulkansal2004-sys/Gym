import { useEffect, useState } from 'react';
import { useApp } from '../app/store';
import { Icon, TopBar } from '../components/ui';
import { CATEGORY_INFO, UNAVAILABLE_CATEGORIES, connect, disconnect, getConnection, sync, syncHistory, type Category, type ConnectionState } from '../wearables/healthConnect';

const OTHER_PROVIDERS = [
  { name: 'Samsung Health', note: 'Writes to Health Connect on Android. Enable sync in Samsung Health › Settings › Health Connect, then connect Health Connect here.' },
  { name: 'Google Fit / Pixel Watch / most Wear OS apps', note: 'Also arrive via Health Connect.' },
  { name: 'Fitbit', note: 'Needs the Fitbit Web API with OAuth and a registered app, which requires a redirect endpoint and token storage. Not implemented in this offline build. Fitbit can also sync into Health Connect on recent Android versions.' },
  { name: 'Garmin', note: 'Garmin Health API requires developer-programme approval and a server to receive data. Not implemented. Garmin Connect can share steps/sleep to Health Connect.' },
  { name: 'Apple Health', note: 'iPhone only; needs the iOS build of this app with HealthKit entitlements. Not applicable to Android.' },
];

export function Devices() {
  const { toast } = useApp();
  const [c, setC] = useState<ConnectionState | null>(null);
  const [sel, setSel] = useState<Category[]>(['steps', 'active-calories', 'workouts', 'weight']);
  const [hist, setHist] = useState<Awaited<ReturnType<typeof syncHistory>>>([]);
  const [busy, setBusy] = useState(false);
  const reload = async () => { setC(await getConnection()); setHist(await syncHistory()); };
  useEffect(() => { void reload(); }, []);

  async function doConnect() {
    setBusy(true);
    try {
      const r = await connect(sel);
      toast(r.granted.length ? `Connected: ${r.granted.map((g) => CATEGORY_INFO[g].label).join(', ')}` : 'No categories were granted');
      if (r.granted.length) await sync();
    } catch (e) { toast((e as Error).message); } finally { setBusy(false); await reload(); }
  }
  async function doSync() {
    setBusy(true);
    const r = await sync();
    toast(r.error ? `Sync failed: ${r.error}` : `Synced ${r.records} records`);
    setBusy(false); await reload();
  }

  return (
    <div className="screen">
      <TopBar title="Connected devices" backTo="/profile" />
      <div className="card">
        <div className="row"><span className="icon-box"><Icon name="watch" /></span><div className="col grow"><b>Android Health Connect</b><span className="small muted">{c?.status === 'connected' ? `Connected · last sync ${c.lastSyncAt ? new Date(c.lastSyncAt).toLocaleString() : 'never'}` : c?.available ? 'Available on this phone' : 'Not available (install Health Connect from Play Store, or open in the Android app)'}</span></div>
          <span className={'pill ' + (c?.status === 'connected' ? 'good' : c?.status === 'error' ? 'bad' : 'grey')}>{c?.status ?? '…'}</span></div>
        {c?.lastError && <span className="small" style={{ color: 'var(--bad-fg)' }}>{c.lastError}</span>}
        <b style={{ fontSize: 13 }}>Data categories</b>
        {(Object.keys(CATEGORY_INFO) as Category[]).map((k) => {
          const granted = c?.scopes.includes(k);
          const on = sel.includes(k);
          return (
            <label key={k} className="row small" style={{ cursor: 'pointer' }}>
              <input type="checkbox" checked={c?.status === 'connected' ? !!granted : on} disabled={c?.status === 'connected'} onChange={(e) => setSel(e.target.checked ? [...sel, k] : sel.filter((x) => x !== k))} />
              <span className="grow">{CATEGORY_INFO[k].label}</span>
              {c?.status === 'connected' && <span className={'pill ' + (granted ? 'good' : 'grey')} style={{ fontSize: 10 }}>{granted ? 'synced' : 'not authorised'}</span>}
            </label>
          );
        })}
        <span className="tiny muted">Not available through this app's plugin: {UNAVAILABLE_CATEGORIES.join(', ')}. These are shown as unavailable, never estimated.</span>
        <div className="card soft small" style={{ gap: 4 }}>
          <b>Privacy</b>
          <span>Data is read from Health Connect into this phone's local database only. Nothing is uploaded. Only the categories you grant are read; Health Connect limits history to 30 days before first consent. You revoke access in the Health Connect app at any time; disconnecting here also deletes the synced copies.</span>
        </div>
        {c?.status !== 'connected'
          ? <button className="btn md" disabled={busy || !c?.available} onClick={doConnect}>{busy ? 'Requesting…' : 'Connect and grant permissions'}</button>
          : <div className="row"><button className="btn md" disabled={busy} onClick={doSync}>{busy ? 'Syncing…' : 'Sync now'}</button><button className="btn secondary md" onClick={async () => { if (confirm('Disconnect and delete synced data?')) { await disconnect(); await reload(); } }}>Disconnect</button></div>}
      </div>
      {hist.length > 0 && (
        <div className="card">
          <b style={{ fontSize: 14 }}>Sync history</b>
          {hist.map((h, i) => <div key={i} className="row small"><span className="grow muted">{new Date(h.startedAt).toLocaleString()}</span><span>{h.records} rec</span><span className={'pill ' + (h.status === 'ok' ? 'good' : h.status === 'error' ? 'bad' : 'grey')} style={{ fontSize: 10 }}>{h.status}</span></div>)}
        </div>
      )}
      <div className="card">
        <b style={{ fontSize: 14 }}>Other trackers</b>
        {OTHER_PROVIDERS.map((p) => <div key={p.name} className="col" style={{ gap: 2 }}><b style={{ fontSize: 13 }}>{p.name}</b><span className="tiny muted">{p.note}</span></div>)}
        <span className="tiny muted">This app never asks for a tracker account password.</span>
      </div>
    </div>
  );
}

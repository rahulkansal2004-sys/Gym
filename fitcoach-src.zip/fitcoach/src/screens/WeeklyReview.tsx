import { useEffect, useState } from 'react';
import { useApp } from '../app/store';
import * as repo from '../db/repos';
import { computeWeeklyReview, createProgrammeFromProfile } from '../app/services';
import type { WeeklyReview } from '../engine/review';
import { weeklyReviewNarrative, deterministicReviewText, type CoachAnswer } from '../ai/coach';
import { TopBar } from '../components/ui';
import { db } from '../db';
import { localDate, uid, nowIso } from '../lib/time';
import { navigate } from '../lib/router';

export function WeeklyReviewScreen() {
  const { profile, goal, programme, refresh, toast } = useApp();
  const [review, setReview] = useState<WeeklyReview | null>(null);
  const [ai, setAi] = useState<CoachAnswer | null>(null);
  const [busy, setBusy] = useState(false);
  const [decision, setDecision] = useState<Record<string, 'accept' | 'reject' | 'defer'>>({});
  const [changed, setChanged] = useState<'no' | 'yes' | null>(null);

  useEffect(() => { void computeWeeklyReview().then(setReview); }, []);

  async function narrate() {
    if (!review) return;
    setBusy(true);
    setAi(await weeklyReviewNarrative(review, profile, goal));
    setBusy(false);
  }

  async function applyDeload() {
    if (!programme) return;
    const all = await repo.listPlannedWorkouts(programme.id);
    const today = localDate();
    const next = all.filter((w) => w.scheduledDate >= today && w.status === 'planned').slice(0, programme.daysPerWeek);
    for (const w of next) {
      w.exercises = w.exercises.map((e) => ({ ...e, sets: e.sets > 2 && e.role !== 'cardio' ? e.sets - 1 : e.sets }));
      w.name = w.name.includes('lighter') ? w.name : w.name + ' (lighter week)';
      await repo.updatePlannedWorkout(w);
    }
    await repo.audit('programme', programme.id, 'deload-applied', `${next.length} sessions`);
    toast('Next week set to lighter volume');
  }

  async function saveDecisions() {
    if (!review || !programme) return;
    await db().run('INSERT INTO programme_reviews(id, programme_id, week, summary_json, decision, created_at) VALUES(?,?,?,?,?,?)', [
      uid(), programme.id, 0, JSON.stringify({ summary: review.summary, recommendations: review.recommendations }), JSON.stringify(decision), nowIso(),
    ]);
    if (review.recommendations.some((r) => r.action === 'deload' && decision[r.id] === 'accept')) await applyDeload();
    toast('Review saved');
    navigate('/');
  }

  async function rebuild() {
    if (!goal) return;
    if (!confirm('Build a new 12-week block from your current profile and goal? Completed history is kept; remaining planned sessions of the old block are archived.')) return;
    await createProgrammeFromProfile(profile, goal.primaryGoal);
    await refresh();
    toast('New block created');
    navigate('/workouts');
  }

  if (!review) return <div className="screen no-tabs"><TopBar title="Weekly review" backTo="/" /><div className="empty">Analysing your week…</div></div>;
  const blockDone = programme && review.adherence.planned === 0;

  return (
    <div className="screen no-tabs">
      <TopBar title="Weekly review" backTo="/" sub="Built from your recorded data only" />
      <div className="card">
        <div className="row between"><b>Summary</b><span className="pill">From your logs</span></div>
        <p className="small" style={{ lineHeight: '19px', whiteSpace: 'pre-wrap' }}>{ai?.text ?? deterministicReviewText(review)}</p>
        {ai?.note && <span className="tiny muted">{ai.note}</span>}
        {!ai && <button className="btn secondary md" disabled={busy} onClick={narrate}>{busy ? 'Asking Gemini…' : 'Explain with AI coach'}</button>}
      </div>
      <div className="grid3">
        <div className="card stat"><b>{review.adherence.completed}/{review.adherence.planned}</b><span className="tiny muted">sessions</span></div>
        <div className="card stat"><b>{review.strength.filter((s) => s.trend === 'up').length}↑ {review.strength.filter((s) => s.trend === 'down').length}↓</b><span className="tiny muted">lifts</span></div>
        <div className="card stat"><b>{review.hydration.daysOnTarget}/{review.hydration.daysLogged}</b><span className="tiny muted">water days</span></div>
      </div>
      {review.strength.length > 0 && (
        <div className="card">
          <b>Strength (estimated 1RM, estimate)</b>
          {review.strength.slice(0, 6).map((s) => <div key={s.exerciseId} className="row small"><span className="grow">{s.name}</span><span>{s.prevE1rm ?? '—'} → <b>{s.bestE1rm ?? '—'}</b> kg</span><span className={'pill ' + (s.trend === 'up' ? 'good' : s.trend === 'down' ? 'warn' : 'grey')} style={{ fontSize: 10 }}>{s.trend}</span></div>)}
        </div>
      )}
      <div className="card">
        <b>Recommendations</b>
        {review.recommendations.length === 0 && <span className="small muted">Nothing to change this week.</span>}
        {review.recommendations.map((r) => (
          <div key={r.id} className="col" style={{ gap: 6, paddingTop: 6, borderTop: '1px solid #F1F5F9' }}>
            <b style={{ fontSize: 14 }}>{r.title}</b>
            <span className="small muted">{r.why}</span>
            {(r.action === 'deload' || r.action === 'schedule') && (
              <div className="grid3">
                {(['accept', 'defer', 'reject'] as const).map((d) => <button key={d} className={'choice' + (decision[r.id] === d ? ' on' : '')} style={{ minHeight: 38, fontSize: 13 }} aria-pressed={decision[r.id] === d} onClick={() => setDecision({ ...decision, [r.id]: d })}>{d}</button>)}
              </div>
            )}
          </div>
        ))}
      </div>
      <div className="card">
        <b>Has your schedule or goal changed?</b>
        <div className="grid2"><button className={'choice' + (changed === 'no' ? ' on' : '')} onClick={() => setChanged('no')}>No</button><button className={'choice' + (changed === 'yes' ? ' on' : '')} onClick={() => setChanged('yes')}>Yes, update</button></div>
        {changed === 'yes' && <div className="row"><a href="#/edit-profile/training" className="btn secondary md">Change days / time</a><a href="#/edit-profile/goal" className="btn secondary md">Change goal</a></div>}
      </div>
      {review.dataGaps.length > 0 && <div className="card warn small">{review.dataGaps.join(' ')}</div>}
      {blockDone && <div className="card soft"><b>Block complete</b><span className="small muted">Build the next 12-week block from your actual progress. Exercises are kept where they are working; loads start from your logged history.</span><button className="btn md" onClick={rebuild}>Build next block</button></div>}
      <button className="btn" onClick={saveDecisions}>Save review</button>
      <span className="tiny muted">Correlation is not causation: trends here describe what was logged, not why. General fitness guidance, not medical advice.</span>
    </div>
  );
}

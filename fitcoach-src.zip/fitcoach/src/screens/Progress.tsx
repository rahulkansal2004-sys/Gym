import { useEffect, useState } from 'react';
import * as repo from '../db/repos';
import type { Measurement, PersonalRecord, Exercise } from '../db/types';
import { Icon, LineChart } from '../components/ui';
import { estimateOneRm } from '../engine/progression';
import { daySummaries, getConnection, type DaySummary } from '../wearables/healthConnect';
import { BarChart } from '../components/ui';
import { exportCsv } from '../lib/export';

export function Progress() {
  const [tab, setTab] = useState<'weight' | 'strength' | 'activity'>('weight');
  const [weights, setWeights] = useState<Measurement[]>([]);
  const [others, setOthers] = useState<Measurement[]>([]);
  const [prs, setPrs] = useState<PersonalRecord[]>([]);
  const [exs, setExs] = useState<Map<string, Exercise>>(new Map());
  const [exId, setExId] = useState<string | null>(null);
  const [history, setHistory] = useState<{ x: string; y: number }[]>([]);
  const [act, setAct] = useState<DaySummary[] | null>(null);
  const [range, setRange] = useState<30 | 90 | 365>(90);

  useEffect(() => {
    (async () => {
      const all = await repo.listMeasurements(undefined, 2000);
      setWeights(all.filter((m) => m.type === 'weight'));
      setOthers(all.filter((m) => m.type !== 'weight'));
      const p = await repo.listPersonalRecords();
      setPrs(p);
      const ids = [...new Set(p.map((x) => x.exerciseId))];
      setExs(await repo.getExercisesByIds(ids));
      if (!exId && ids[0]) setExId(ids[0]);
      const c = await getConnection();
      if (c.status === 'connected') setAct(await daySummaries(7));
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    (async () => {
      if (!exId) return;
      const sets = await repo.exerciseHistory(exId, 500);
      const bySession = new Map<string, { date: string; best: number }>();
      for (const s of sets) {
        const e1 = estimateOneRm(s.weightKg, s.reps) ?? 0;
        const d = s.loggedAt.slice(5, 10);
        const cur = bySession.get(s.sessionId);
        if (!cur || e1 > cur.best) bySession.set(s.sessionId, { date: d, best: e1 });
      }
      setHistory([...bySession.values()].reverse().map((v) => ({ x: v.date, y: v.best })));
    })();
  }, [exId]);

  const cutoff = new Date(Date.now() - range * 86400000).toISOString().slice(0, 10);
  const wPoints = weights.filter((m) => m.localDate >= cutoff).reverse().map((m) => ({ x: m.localDate.slice(5), y: m.value }));
  const latestW = weights[0];
  const firstW = weights[weights.length - 1];
  const latestByType = new Map<string, Measurement[]>();
  for (const m of others) { if (!latestByType.has(m.type)) latestByType.set(m.type, []); latestByType.get(m.type)!.push(m); }

  return (
    <div className="screen">
      <div className="row between">
        <h1>Progress</h1>
        <button className="btn ghost sm" onClick={() => exportCsv('measurements.csv', [...weights, ...others].map((m) => ({ date: m.localDate, type: m.type, value: m.value, unit: m.unit, note: m.note ?? '' })))}><Icon name="download" size={16} />CSV</button>
      </div>
      <div className="tabs" role="tablist">
        {(['weight', 'strength', 'activity'] as const).map((t) => <button key={t} role="tab" aria-selected={tab === t} className={tab === t ? 'on' : ''} onClick={() => setTab(t)}>{t[0].toUpperCase() + t.slice(1)}</button>)}
      </div>

      {tab === 'weight' && (
        <>
          <div className="card">
            <div className="row between"><b>Body weight</b><div className="row" style={{ gap: 4 }}>{([30, 90, 365] as const).map((r) => <button key={r} className={'pill ' + (range === r ? '' : 'grey')} style={{ border: 0, cursor: 'pointer' }} onClick={() => setRange(r)}>{r === 365 ? '1Y' : r + 'D'}</button>)}</div></div>
            {latestW ? (
              <div className="row" style={{ alignItems: 'baseline' }}>
                <span className="big">{latestW.value} kg</span>
                {firstW && firstW.id !== latestW.id && <span className="small" style={{ color: 'var(--blue)', fontWeight: 600 }}>{(latestW.value - firstW.value > 0 ? '+' : '') + (latestW.value - firstW.value).toFixed(1)} kg since {firstW.localDate}</span>}
              </div>
            ) : null}
            <LineChart points={wPoints} unit="kg" label="Body weight over time" />
            <span className="tiny muted">Daily weight swings with water and food. Read it together with waist and strength, not on its own. Scale weight alone does not establish fat loss or muscle gain.</span>
            <a href="#/measurements" className="btn secondary md">Add or edit measurements</a>
          </div>
          <div className="card">
            <b>Other measurements</b>
            {latestByType.size === 0 && <span className="small muted">No waist, chest, arm or other measurements yet.</span>}
            {[...latestByType.entries()].map(([type, list]) => {
              const latest = list[0], oldest = list[list.length - 1], prev = list[1];
              return (
                <div key={type} className="row small">
                  <span className="grow muted" style={{ textTransform: 'capitalize' }}>{type}</span>
                  <b>{latest.value} {latest.unit}</b>
                  <span style={{ minWidth: 110, textAlign: 'right', color: 'var(--blue)', fontWeight: 600 }}>{prev ? `${fmt(latest.value - prev.value)} vs last` : ''}{oldest !== latest ? ` · ${fmt(latest.value - oldest.value)} since start` : ''}</span>
                </div>
              );
            })}
          </div>
        </>
      )}

      {tab === 'strength' && (
        <>
          <div className="card">
            <b>Exercise history</b>
            {exs.size === 0 && <span className="small muted">Complete a workout with logged loads to see strength trends.</span>}
            {exs.size > 0 && (
              <select className="input" aria-label="Exercise" value={exId ?? ''} onChange={(e) => setExId(e.target.value)}>
                {[...exs.values()].map((e) => <option key={e.id} value={e.id}>{e.name}</option>)}
              </select>
            )}
            {exId && <LineChart points={history} unit="kg est. 1RM" label="Estimated one-rep max per session" />}
            <span className="tiny muted">Estimated 1RM (Epley) from your best set each session, only for 1–12 rep sets. An estimate, not a tested max. Different variations are tracked separately.</span>
          </div>
          <div className="card">
            <b>Personal records</b>
            {prs.length === 0 && <span className="small muted">None yet.</span>}
            {prs.slice(0, 20).map((p) => (
              <div key={p.id} className="row small">
                <div className="col grow"><b style={{ fontSize: 13 }}>{exs.get(p.exerciseId)?.name ?? p.exerciseId}</b><span className="tiny muted">{p.achievedAt.slice(0, 10)}</span></div>
                <span className="pill">{p.type === 'heaviest' ? `${p.weightKg} kg × ${p.reps}` : p.type === 'best-e1rm' ? `est. 1RM ${p.value} kg` : `${p.reps} reps @ ${p.weightKg} kg`}</span>
              </div>
            ))}
          </div>
        </>
      )}

      {tab === 'activity' && (
        <div className="card">
          <b>Activity from Health Connect</b>
          {!act && <span className="small muted">No tracker connected. <a href="#/devices">Connect Health Connect</a> to see steps, active calories and recorded workouts here. Nothing is estimated.</span>}
          {act && (
            <>
              <BarChart bars={act.map((d) => ({ x: d.date.slice(8), y: d.steps ?? 0 }))} target={Number(localStorage.getItem('steps_target') ?? 8000)} label="Steps per day, last 7 days" unit="steps" />
              <div className="row small muted">{act.filter((d) => d.steps == null).length > 0 && <span>Days without data are shown as empty, not zero.</span>}</div>
              {act.map((d) => (
                <div key={d.date} className="row small"><span className="grow muted">{d.date}</span><span>{d.steps != null ? d.steps.toLocaleString() + ' steps' : '—'}</span><span>{d.activeKcal != null ? Math.round(d.activeKcal) + ' kcal' : '—'}</span><span>{d.workoutMinutes != null ? d.workoutMinutes + ' min' : '—'}</span></div>
              ))}
              <span className="tiny muted">Tracker-recorded data. Manual entries and app estimates are kept separate.</span>
            </>
          )}
        </div>
      )}
    </div>
  );
}

function fmt(n: number): string {
  const v = Math.round(n * 10) / 10;
  return (v > 0 ? '+' : '') + v;
}

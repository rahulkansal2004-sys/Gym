import { useCallback, useEffect, useRef, useState } from 'react';
import { useApp } from '../app/store';
import * as repo from '../db/repos';
import type { Exercise, ExerciseLog, Session, SetLog } from '../db/types';
import type { BodyArea } from '../data/exercises';
import { Icon, Sheet, Stepper, TopBar } from '../components/ui';
import { suggestSubstitutes, assessSymptom, type SubstitutionReason } from '../engine/substitution';
import { suggestLoad, isBodyweightLoad } from '../engine/progression';
import { finishAndReport } from '../app/services';
import { formatHm } from '../lib/time';
import { navigate } from '../lib/router';

interface PersistedState {
  exerciseIndex: number;
  restEndsAt: number | null; // epoch ms
  restPausedRemaining: number | null; // seconds left while paused
  draft: Record<string, { kg: number; reps: number }>; // per exercise log id
}

export function ActiveSession({ id }: { id?: string }) {
  const { profile, refresh, toast } = useApp();
  const [session, setSession] = useState<Session | null>(null);
  const [logs, setLogs] = useState<ExerciseLog[]>([]);
  const [sets, setSets] = useState<SetLog[]>([]);
  const [exs, setExs] = useState<Map<string, Exercise>>(new Map());
  const [st, setSt] = useState<PersistedState>({ exerciseIndex: 0, restEndsAt: null, restPausedRemaining: null, draft: {} });
  const [now, setNow] = useState(Date.now());
  const [last, setLast] = useState<SetLog[]>([]);
  const [suggestion, setSuggestion] = useState<string | null>(null);
  const [sheet, setSheet] = useState<'none' | 'swap' | 'pain' | 'finish' | 'notes'>('none');
  const [swapReason, setSwapReason] = useState<SubstitutionReason>('equipment');
  const [painText, setPainText] = useState('');
  const [painArea, setPainArea] = useState<BodyArea | null>(null);
  const [painResult, setPainResult] = useState<ReturnType<typeof assessSymptom> | null>(null);
  const [rpe, setRpe] = useState<number | null>(null);
  const [soreness, setSoreness] = useState<number | null>(null);
  const [notes, setNotes] = useState('');
  const [allExercises, setAllExercises] = useState<Exercise[]>([]);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const load = useCallback(async () => {
    if (!id) return;
    const s = await repo.getSession(id);
    if (!s) { navigate('/workouts', true); return; }
    if (s.status !== 'in_progress') { navigate(`/summary/${s.id}`, true); return; }
    const l = await repo.listExerciseLogs(id);
    const ss = await repo.listSetLogs(id);
    const map = await repo.getExercisesByIds(l.map((x) => x.exerciseId));
    const saved = await repo.loadSessionState<PersistedState>(id);
    setSession(s); setLogs(l); setSets(ss); setExs(map);
    if (saved) setSt(saved);
    setAllExercises(await repo.listExercises());
  }, [id]);

  useEffect(() => { void load(); }, [load]);
  useEffect(() => { const t = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(t); }, []);

  // Persist state (debounced) so the workout survives app closure.
  const persist = useCallback((next: PersistedState) => {
    setSt(next);
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => { if (id) void repo.saveSessionState(id, next); }, 250);
  }, [id]);

  const current = logs[st.exerciseIndex];
  const ex = current ? exs.get(current.exerciseId) : undefined;
  const mySets = current ? sets.filter((s) => s.exerciseLogId === current.id).sort((a, b) => a.setIndex - b.setIndex) : [];
  const doneCount = mySets.filter((s) => s.completed).length;
  const nextSetIndex = doneCount;
  const draft = current ? st.draft[current.id] ?? null : null;

  // Previous performance and suggestion for the current exercise.
  useEffect(() => {
    (async () => {
      if (!current || !ex || !id) return;
      const prev = await repo.lastPerformance(current.exerciseId, id);
      setLast(prev);
      const hist = await repo.exerciseHistory(current.exerciseId, 40);
      const prevSessionId = hist.find((s) => s.sessionId !== prev[0]?.sessionId)?.sessionId;
      const prev2 = prevSessionId ? hist.filter((s) => s.sessionId === prevSessionId) : [];
      const lastSession = (await repo.listSessions(1))[0];
      const sug = suggestLoad(ex, current.repMin, current.repMax, prev, prev2, lastSession?.rpe ?? null, null);
      setSuggestion(sug.kg != null ? `${sug.kg} kg suggested: ${sug.reason}` : sug.reason);
      if (!st.draft[current.id]) {
        const kg = sug.kg ?? (prev[0]?.weightKg ?? 0);
        persist({ ...st, draft: { ...st.draft, [current.id]: { kg, reps: current.repMax || 0 } } });
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [current?.id, ex?.id]);

  if (!session || !current || !ex) {
    return <div className="screen no-tabs"><TopBar title="Workout" backTo="/workouts" /><div className="empty">{logs.length === 0 && session ? 'This session has no exercises.' : 'Loading…'}</div>{session && logs.length === 0 && <button className="btn" onClick={() => finish('abandoned')}>End session</button>}</div>;
  }

  const restRemaining = st.restPausedRemaining != null ? st.restPausedRemaining : st.restEndsAt ? Math.max(0, Math.round((st.restEndsAt - now) / 1000)) : null;
  const restRunning = st.restEndsAt != null && st.restPausedRemaining == null && restRemaining! > 0;
  const bodyweight = isBodyweightLoad(ex);
  const timed = current.repMax === 0;

  function setDraft(patch: Partial<{ kg: number; reps: number }>) {
    persist({ ...st, draft: { ...st.draft, [current!.id]: { ...(draft ?? { kg: 0, reps: 0 }), ...patch } } });
  }

  async function completeSet() {
    if (!draft) return;
    const row = await repo.upsertSetLog({ exerciseLogId: current!.id, sessionId: session!.id, exerciseId: current!.exerciseId, setIndex: nextSetIndex, weightKg: bodyweight ? 0 : draft.kg, reps: timed ? 1 : draft.reps, completed: true, rpe: null });
    setSets((xs) => [...xs.filter((s) => s.id !== row.id), row]);
    const isLast = nextSetIndex + 1 >= current!.plannedSets;
    persist({ ...st, restEndsAt: isLast ? null : Date.now() + current!.restSeconds * 1000, restPausedRemaining: null });
    if (isLast) toast('All sets logged. Move to the next exercise when ready.');
  }

  async function editSet(s: SetLog) {
    const kg = Number(prompt(`Weight (kg) for set ${s.setIndex + 1}`, String(s.weightKg)) ?? s.weightKg);
    const reps = Number(prompt(`Reps for set ${s.setIndex + 1}`, String(s.reps)) ?? s.reps);
    if (Number.isNaN(kg) || Number.isNaN(reps)) return;
    const row = await repo.upsertSetLog({ ...s, weightKg: kg, reps });
    setSets((xs) => xs.map((x) => (x.id === row.id ? row : x)));
  }

  function togglePause() {
    if (st.restEndsAt == null) { persist({ ...st, restEndsAt: Date.now() + current!.restSeconds * 1000, restPausedRemaining: null }); return; }
    if (st.restPausedRemaining != null) persist({ ...st, restEndsAt: Date.now() + st.restPausedRemaining * 1000, restPausedRemaining: null });
    else persist({ ...st, restPausedRemaining: restRemaining });
  }

  function go(delta: number) {
    const next = Math.min(logs.length - 1, Math.max(0, st.exerciseIndex + delta));
    persist({ ...st, exerciseIndex: next, restEndsAt: null, restPausedRemaining: null });
  }

  async function skipExercise() {
    const l = { ...current!, skipped: true };
    await repo.updateExerciseLog(l);
    setLogs((xs) => xs.map((x) => (x.id === l.id ? l : x)));
    if (st.exerciseIndex < logs.length - 1) go(1);
  }

  async function substitute(to: Exercise, reason: SubstitutionReason) {
    setExs((m) => new Map(m).set(to.id, to));
    setSheet('none');
    if (doneCount > 0) {
      // Sets already logged stay with the original exercise (different variations are never merged).
      // The substitute becomes a new entry right after it, for the remaining sets.
      const remaining = Math.max(1, current!.plannedSets - doneCount);
      const added = await repo.addExerciseLog(session!.id, to.id, current!.orderIndex + 1, remaining, current!.repMin, current!.repMax, current!.restSeconds);
      added.substitutedFrom = current!.exerciseId; added.substitutionReason = reason;
      await repo.updateExerciseLog(added);
      const trimmed = { ...current!, notes: `${current!.notes ?? ''}\nSwapped to ${to.name} after ${doneCount} set${doneCount > 1 ? 's' : ''} (${reason})`.trim() };
      await repo.updateExerciseLog(trimmed);
      const next = [...logs.map((x) => (x.id === trimmed.id ? trimmed : x))];
      next.splice(st.exerciseIndex + 1, 0, added);
      setLogs(next);
      persist({ ...st, exerciseIndex: st.exerciseIndex + 1, restEndsAt: null, restPausedRemaining: null });
    } else {
      const l = { ...current!, exerciseId: to.id, substitutedFrom: current!.substitutedFrom ?? current!.exerciseId, substitutionReason: reason };
      await repo.updateExerciseLog(l);
      setLogs((xs) => xs.map((x) => (x.id === l.id ? l : x)));
    }
    toast(`Swapped to ${to.name}`);
  }

  async function reportPain() {
    const r = assessSymptom(painText, painArea);
    setPainResult(r);
    const l = { ...current!, painReported: true, notes: `${current!.notes ?? ''}\nPain: ${painText}${painArea ? ` (${painArea})` : ''}`.trim() };
    await repo.updateExerciseLog(l);
    setLogs((xs) => xs.map((x) => (x.id === l.id ? l : x)));
    if (painArea && !profile.restrictions.includes(painArea)) {
      // Do not silently change the profile; record it as a note for the weekly review instead.
      await repo.audit('session', session!.id, 'pain-report', `${painArea}: ${painText}`);
    }
  }

  async function finish(status: 'completed' | 'abandoned') {
    try {
      const report = await finishAndReport(session!.id, status, rpe, notes || null);
      if (soreness != null) await repo.upsertRecovery({ localDate: new Date().toISOString().slice(0, 10), sleepHours: null, sleepQuality: null, energy: null, soreness, recovery: null, stress: null, readiness: null, source: 'manual' });
      await refresh();
      navigate(`/summary/${report.session.id}`, true);
    } catch (e) { toast((e as Error).message); }
  }

  const subs = sheet === 'swap' ? suggestSubstitutes(ex, swapReason, profile, allExercises, painArea ? [painArea] : []) : [];

  return (
    <div className="screen no-tabs" style={{ gap: 12 }}>
      <TopBar title={ex.name} backTo="/" sub={`Exercise ${st.exerciseIndex + 1} of ${logs.length} · Set ${Math.min(nextSetIndex + 1, current.plannedSets)} of ${current.plannedSets}`}
        right={<button className="btn secondary sm" onClick={() => setSheet('swap')}><Icon name="swap" size={16} />Swap</button>} />
      <div className="row" style={{ flexWrap: 'wrap', gap: 6 }}>
        {ex.primaryMuscles.map((m) => <span key={m} className="pill">{m}</span>)}
        {ex.secondaryMuscles.map((m) => <span key={m} className="pill grey">{m}</span>)}
        {current.substitutedFrom && <span className="pill warn">substituted</span>}
        {current.skipped && <span className="pill warn">skipped</span>}
      </div>
      <details className="card" style={{ gap: 6 }}>
        <summary style={{ cursor: 'pointer', fontWeight: 600, fontSize: 14 }}>How to do it <span className="tiny muted">(no demo video: instructions are text, reviewed from standard coaching practice)</span></summary>
        <ol className="small" style={{ margin: 0, paddingLeft: 18, lineHeight: '18px' }}>{ex.execution.map((s, i) => <li key={i}>{s}</li>)}</ol>
        <span className="small muted">Breathing: {ex.breathing}</span>
        <span className="small muted">Watch for: {ex.mistakes.join('; ')}</span>
        <a href={`#/exercises/${ex.id}?from=session`} className="small" style={{ fontWeight: 600 }}>Full details</a>
      </details>
      <div className="row between small muted">
        <span>{timed ? `${current.plannedSets} × ${exs.get(current.exerciseId)?.durationMinutes ?? 1} min` : `Target ${current.repMin}–${current.repMax} reps`} · rest {current.restSeconds} s</span>
        <span>Last time: {last.length ? <b style={{ color: 'var(--ink)' }}>{last.map((s) => `${bodyweight ? '' : s.weightKg + ' kg × '}${s.reps}`).join(', ')}</b> : 'no history'}</span>
      </div>
      {suggestion && <span className="tiny" style={{ color: 'var(--blue)' }}>{suggestion}</span>}

      {!timed && draft && (
        <div className={bodyweight ? 'stack' : 'grid2'}>
          {!bodyweight && (
            <div className="card flat" style={{ padding: 12 }}>
              <span className="small muted" style={{ fontWeight: 600 }}>Weight (kg)</span>
              <Stepper value={draft.kg} onChange={(v) => setDraft({ kg: v })} step={2.5} label="weight" />
            </div>
          )}
          <div className="card flat" style={{ padding: 12 }}>
            <span className="small muted" style={{ fontWeight: 600 }}>Reps</span>
            <Stepper value={draft.reps} onChange={(v) => setDraft({ reps: Math.round(v) })} step={1} label="reps" />
          </div>
        </div>
      )}

      <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>
        {Array.from({ length: current.plannedSets }).map((_, i) => {
          const s = mySets.find((x) => x.setIndex === i && x.completed);
          return (
            <button key={i} type="button" className={'pill ' + (s ? '' : i === nextSetIndex ? '' : 'grey')} style={{ flex: 1, justifyContent: 'center', minHeight: 36, border: 0, cursor: s ? 'pointer' : 'default', background: s ? 'var(--blue)' : i === nextSetIndex ? 'var(--blue-soft)' : 'var(--surface)', color: s ? '#fff' : i === nextSetIndex ? 'var(--blue)' : 'var(--ink-2)' }}
              onClick={() => s && editSet(s)} aria-label={s ? `Edit set ${i + 1}: ${s.weightKg} kg × ${s.reps}` : `Set ${i + 1}`}>
              {s ? (timed ? `Set ${i + 1} ✓` : `${bodyweight ? '' : s.weightKg + '×'}${s.reps}`) : `Set ${i + 1}`}
            </button>
          );
        })}
      </div>

      {doneCount < current.plannedSets
        ? <button className="btn" onClick={completeSet}>Complete set {nextSetIndex + 1}</button>
        : <button className="btn" onClick={() => (st.exerciseIndex < logs.length - 1 ? go(1) : setSheet('finish'))}>{st.exerciseIndex < logs.length - 1 ? 'Next exercise' : 'Finish workout'}</button>}

      <div className="card soft row" style={{ padding: 14 }}>
        <div className="col grow">
          <span className="small muted" style={{ fontWeight: 600 }}>Rest timer</span>
          <span style={{ fontSize: 34, fontWeight: 700, letterSpacing: -1 }} aria-live="polite">{formatHm(restRemaining ?? current.restSeconds)}</span>
          <span className="tiny muted">{restRunning ? 'Next set when it ends' : st.restPausedRemaining != null ? 'Paused' : 'Starts when you complete a set'}</span>
        </div>
        <button className="icon-btn" style={{ background: 'var(--blue)', color: '#fff', borderRadius: 26, width: 52, height: 52 }} aria-label={restRunning ? 'Pause rest timer' : 'Start rest timer'} onClick={togglePause}>
          <Icon name={restRunning ? 'pause' : 'play'} />
        </button>
        <button className="btn secondary sm" onClick={() => persist({ ...st, restEndsAt: null, restPausedRemaining: null })}>Skip rest</button>
      </div>

      <div className="row between" style={{ flexWrap: 'wrap' }}>
        <button className="btn ghost sm" disabled={st.exerciseIndex === 0} onClick={() => go(-1)}>‹ Previous</button>
        <button className="btn ghost sm" onClick={skipExercise}>Skip exercise</button>
        <button className="btn ghost sm" onClick={() => { setNotes(current.notes ?? ''); setSheet('notes'); }}>Note</button>
        <button className="btn ghost sm" disabled={st.exerciseIndex >= logs.length - 1} onClick={() => go(1)}>Next ›</button>
      </div>
      <div className="row between">
        <button className="btn danger sm" onClick={() => { setPainResult(null); setSheet('pain'); }}>Report pain or discomfort</button>
        <button className="btn ghost sm" style={{ color: 'var(--ink-2)' }} onClick={() => setSheet('finish')}>Finish early</button>
      </div>

      <Sheet open={sheet === 'swap'} onClose={() => setSheet('none')} title={`Swap ${ex.name}`}>
        <div className="grid3">
          {(['equipment', 'discomfort', 'preference', 'difficulty', 'time', 'location'] as SubstitutionReason[]).map((r) => (
            <button key={r} className={'choice' + (swapReason === r ? ' on' : '')} style={{ minHeight: 40, fontSize: 13 }} aria-pressed={swapReason === r} onClick={() => setSwapReason(r)}>{r}</button>
          ))}
        </div>
        <div className="stack">
          {subs.length === 0 && <div className="empty">No alternative fits your equipment and restrictions.</div>}
          {subs.map((s) => (
            <button key={s.exercise.id} className="card row" style={{ textAlign: 'left', border: 0, cursor: 'pointer' }} onClick={() => substitute(s.exercise, swapReason)}>
              <div className="col grow"><b style={{ fontSize: 14 }}>{s.exercise.name}</b><span className="small muted">{s.why}</span></div>
              <Icon name="chevron" size={18} color="#475569" />
            </button>
          ))}
        </div>
      </Sheet>

      <Sheet open={sheet === 'pain'} onClose={() => setSheet('none')} title="Pain or discomfort">
        {!painResult ? (
          <>
            <p className="small muted">Describe what you feel. Red-flag symptoms (chest pain, faintness, severe breathlessness, sudden sharp pain or swelling) mean stop and get assessed, not swap.</p>
            <textarea className="input" aria-label="Describe the symptom" value={painText} onChange={(e) => setPainText(e.target.value)} placeholder="e.g. dull ache in the front of my right shoulder on the way up" />
            <div className="grid4">
              {(['knee', 'lower-back', 'shoulder', 'wrist', 'elbow', 'hip', 'neck', 'ankle'] as BodyArea[]).map((a) => (
                <button key={a} className={'choice' + (painArea === a ? ' on' : '')} style={{ minHeight: 40, fontSize: 12, padding: '0 4px' }} aria-pressed={painArea === a} onClick={() => setPainArea(painArea === a ? null : a)}>{a.replace('-', ' ')}</button>
              ))}
            </div>
            <button className="btn" disabled={!painText.trim()} onClick={reportPain}>Assess</button>
          </>
        ) : (
          <>
            <div className={'card ' + (painResult.level === 'emergency' ? 'bad' : painResult.level === 'stop' ? 'warn' : 'soft')}><b>{painResult.level === 'emergency' ? 'Stop and seek urgent care' : painResult.level === 'stop' ? 'Stop this session' : 'Modify and continue carefully'}</b><span className="small">{painResult.message}</span></div>
            {painResult.level === 'modify' ? (
              <div className="row"><button className="btn secondary md" onClick={() => { setSheet('swap'); setSwapReason('discomfort'); }}>Find a substitute</button><button className="btn md" onClick={() => setSheet('none')}>Continue lighter</button></div>
            ) : (
              <button className="btn" onClick={() => finish('abandoned')}>End session now</button>
            )}
            <span className="tiny muted">General fitness guidance, not medical advice.</span>
          </>
        )}
      </Sheet>

      <Sheet open={sheet === 'notes'} onClose={() => setSheet('none')} title="Exercise note">
        <textarea className="input" aria-label="Note" value={notes} onChange={(e) => setNotes(e.target.value)} />
        <button className="btn" onClick={async () => { const l = { ...current!, notes }; await repo.updateExerciseLog(l); setLogs((xs) => xs.map((x) => (x.id === l.id ? l : x))); setNotes(''); setSheet('none'); }}>Save note</button>
      </Sheet>

      <Sheet open={sheet === 'finish'} onClose={() => setSheet('none')} title="Finish workout">
        <p className="small muted">{sets.filter((s) => s.completed).length} of {logs.reduce((a, l) => a + l.plannedSets, 0)} planned sets logged. Only logged sets count; ending early records an honest partial session.</p>
        <span className="small" style={{ fontWeight: 600 }}>How hard was it overall? (1 easy – 10 maximal)</span>
        <div className="grid5">{[2, 4, 6, 8, 10].map((v) => <button key={v} className={'choice' + (rpe === v ? ' on' : '')} aria-pressed={rpe === v} onClick={() => setRpe(v)}>{v}</button>)}</div>
        <span className="small" style={{ fontWeight: 600 }}>Muscle soreness right now (1 none – 5 severe)</span>
        <div className="grid5">{[1, 2, 3, 4, 5].map((v) => <button key={v} className={'choice' + (soreness === v ? ' on' : '')} aria-pressed={soreness === v} onClick={() => setSoreness(v)}>{v}</button>)}</div>
        <textarea className="input" aria-label="Session notes" placeholder="Session notes (optional)" value={notes} onChange={(e) => setNotes(e.target.value)} />
        <button className="btn" onClick={() => finish('completed')}>Save workout</button>
        <button className="btn ghost md" onClick={() => finish('abandoned')}>End without completing</button>
      </Sheet>
    </div>
  );
}

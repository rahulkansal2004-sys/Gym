import { useApp } from '../app/store';
import { Icon } from '../components/ui';
import { GOAL_INFO } from '../engine/programme';

export function Profile() {
  const { profile, goal, programme } = useApp();
  const rows: { href: string; icon: Parameters<typeof Icon>[0]['name']; name: string; sub: string }[] = [
    { href: '#/edit-profile/profile', icon: 'user', name: 'Edit profile', sub: `${profile.heightCm ?? '—'} cm · ${profile.weightKg ?? '—'} kg · ${profile.experience}` },
    { href: '#/edit-profile/goal', icon: 'sparkle', name: 'Training goal', sub: goal ? GOAL_INFO[goal.primaryGoal].label + (goal.secondaryGoal ? ` + ${GOAL_INFO[goal.secondaryGoal].label}` : '') : 'Not set' },
    { href: '#/edit-profile/training', icon: 'dumbbell', name: 'Training setup', sub: `${profile.daysPerWeek} days · ${profile.sessionMinutes} min · ${profile.location}${programme ? ` · ${programme.name}` : ''}` },
    { href: '#/edit-profile/health', icon: 'shield', name: 'Health and restrictions', sub: profile.restrictions.length ? profile.restrictions.join(', ') : 'None reported' },
    { href: '#/edit-profile/preferences', icon: 'leaf', name: 'Diet, units and nutrition tracking', sub: `${profile.diet} · ${profile.unitsWeight}/${profile.unitsLength} · nutrition ${profile.nutritionEnabled ? 'on' : 'off'}` },
    { href: '#/edit-profile/ai', icon: 'sparkle', name: 'AI coach (Gemini)', sub: 'Key handling, proxy or direct, usage cap' },
    { href: '#/reminders', icon: 'bell', name: 'Reminders and notifications', sub: 'Workouts, water, meals, measurements, quiet hours' },
    { href: '#/devices', icon: 'watch', name: 'Connected devices', sub: 'Android Health Connect' },
    { href: '#/recovery', icon: 'moon', name: 'Sleep and recovery', sub: 'Daily check-in' },
    { href: '#/measurements', icon: 'ruler', name: 'Body measurements', sub: 'Weight, waist, chest, arms, thighs…' },
    { href: '#/privacy', icon: 'shield', name: 'Privacy, export and delete', sub: 'Where data lives, export JSON/CSV, delete everything' },
    { href: '#/improve', icon: 'info', name: 'Improve my app', sub: 'Request features or report bugs' },
  ];
  return (
    <div className="screen">
      <div className="row">
        <span className="avatar" style={{ width: 56, height: 56, borderRadius: 28, fontSize: 18 }}>{(profile.name ?? 'Me').slice(0, 2).toUpperCase()}</span>
        <div className="col grow"><h1 style={{ fontSize: 20 }}>{profile.name ?? 'Your profile'}</h1><span className="small muted">{goal ? GOAL_INFO[goal.primaryGoal].label : ''} · {profile.daysPerWeek} days a week · {profile.location}</span></div>
      </div>
      <div className="card" style={{ padding: '4px 16px' }}>
        {rows.map((r) => (
          <a key={r.href + r.name} href={r.href} className="list-item" style={{ color: 'inherit', minHeight: 54 }}>
            <span className="icon-box sm"><Icon name={r.icon} size={18} /></span>
            <div className="col grow"><b style={{ fontSize: 14 }}>{r.name}</b><span className="tiny muted">{r.sub}</span></div>
            <Icon name="chevron" size={18} color="#475569" />
          </a>
        ))}
      </div>
      <span className="tiny muted" style={{ textAlign: 'center' }}>FitCoach 0.1.0 · offline-first · no account, no cloud. A fitness tool, not medical advice.</span>
    </div>
  );
}

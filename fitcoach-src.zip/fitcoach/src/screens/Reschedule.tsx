import { useEffect, useState } from 'react';
import { useApp } from '../app/store';
import * as repo from '../db/repos';
import type { PlannedWorkout } from '../db/types';
import { TopBar } from '../components/ui';
import { missedWorkouts, rescheduleForward, skipMissed, deferToEnd, type ReschedulePlan } from '../engine/schedule';
import { localDate } from '../lib/time';
import { navigate } from '../lib/router';

const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

export function Reschedule() {
  const { programme, toast, refresh } = useApp();
  const [all, setAll] = useState<PlannedWorkout[]>([]);
  const [weekdays, setWeekdays] = useState<number[]>([]);
  const [plan, setPlan] = useState<ReschedulePlan | null>(null);
  const today = localDate();

  useEffect(() => {
    (async () => {
      if (!programme) return;
      setAll(await repo.listPlannedWorkouts(programme.id));
      setWeekdays((programme.config.trainingWeekdays as number[]) ?? []);
    })();
  }, [programme]);

  if (!programme) return <div className="screen no-tabs"><TopBar title="Schedule" backTo="/" /><div className="empty">No active programme.</div></div>;
  const missed = missedWorkouts(all, today);

  async function apply(p: ReschedulePlan) {
    if (p.substantial && !confirm(p.description + '\n\nApply this change?')) return;
    for (const c of p.changes) {
      const w = all.find((x) => x.id === c.id)!;
      await repo.updatePlannedWorkout({ ...w, scheduledDate: c.to, status: w.status === 'planned' ? 'rescheduled' : w.status });
    }
    for (const s of p.skipped) {
      const w = all.find((x) => x.id === s.id)!;
      await repo.updatePlannedWorkout({ ...w, status: 'skipped' });
    }
    await repo.audit('programme', programme!.id, 'reschedule', p.description);
    await refresh();
    toast('Schedule updated');
    navigate('/workouts');
  }

  async function saveWeekdays() {
    if (weekdays.length !== programme!.daysPerWeek) { toast(`Pick exactly ${programme!.daysPerWeek} days`); return; }
    const sorted = [...weekdays].sort((a, b) => a - b);
    await repo.setSetting('training_weekdays', JSON.stringify(sorted));
    // Re-date all future planned sessions onto the new weekdays, in order, from today.
    const future = all.filter((w) => w.scheduledDate >= today && (w.status === 'planned' || w.status === 'rescheduled')).sort((a, b) => a.scheduledDate.localeCompare(b.scheduledDate));
    const p = rescheduleForward(future.map((w) => ({ ...w, scheduledDate: '0000-00-00' })), sorted, today); // force every session to be re-dated
    for (const c of p.changes) { const w = future.find((x) => x.id === c.id)!; await repo.updatePlannedWorkout({ ...w, scheduledDate: c.to }); }
    await repo.audit('programme', programme!.id, 'weekdays', sorted.join(','));
    await refresh();
    toast('Training days updated');
    navigate('/workouts');
  }

  return (
    <div className="screen no-tabs">
      <TopBar title="Schedule" backTo="/workouts" />
      <div className="card">
        <b>Missed sessions: {missed.length}</b>
        {missed.length === 0 && <span className="small muted">Nothing missed. Change your training days below if your week has changed.</span>}
        {missed.map((w) => <span key={w.id} className="small muted">{w.scheduledDate} · {w.name}</span>)}
        {missed.length > 0 && (
          <div className="stack">
            <button className="btn secondary md" onClick={() => setPlan(rescheduleForward(all, weekdays, today))}>Reschedule forward</button>
            <button className="btn secondary md" onClick={() => setPlan(skipMissed(all, today))}>Skip them</button>
            <button className="btn secondary md" onClick={() => setPlan(deferToEnd(all, weekdays, today))}>Move to end of block</button>
          </div>
        )}
        {plan && (
          <div className="card soft">
            <b style={{ fontSize: 14 }}>Proposed change</b>
            <span className="small">{plan.description}</span>
            {plan.changes.slice(0, 6).map((c) => <span key={c.id} className="tiny muted">{c.name}: {c.from} → {c.to}</span>)}
            {plan.changes.length > 6 && <span className="tiny muted">…and {plan.changes.length - 6} more</span>}
            <span className="tiny muted">Never two sessions on one day; the split order is preserved so recently trained muscles get their rest.</span>
            <button className="btn md" onClick={() => apply(plan)}>Confirm</button>
          </div>
        )}
      </div>
      <div className="card">
        <b>Training days ({programme.daysPerWeek} per week)</b>
        <div className="row" style={{ gap: 6 }}>
          {DAYS.map((d, i) => { const n = i + 1; const on = weekdays.includes(n); return <button key={d} className={'choice' + (on ? ' on' : '')} style={{ flex: 1, minHeight: 40, padding: 0, fontSize: 12 }} aria-pressed={on} onClick={() => setWeekdays(on ? weekdays.filter((x) => x !== n) : [...weekdays, n])}>{d}</button>; })}
        </div>
        <span className="tiny muted">Future sessions are re-dated onto these days in their existing order. Completed sessions are untouched.</span>
        <button className="btn md" onClick={saveWeekdays}>Save training days</button>
      </div>
    </div>
  );
}

import { useEffect, useState } from 'react';
import { useApp } from '../app/store';
import * as repo from '../db/repos';
import type { PlannedWorkout, Session } from '../db/types';
import { Icon } from '../components/ui';
import { localDate } from '../lib/time';
import { navigate } from '../lib/router';

export function Workouts() {
  const { programme, inProgress } = useApp();
  const [tab, setTab] = useState<'plan' | 'history'>('plan');
  const [plan, setPlan] = useState<PlannedWorkout[]>([]);
  const [history, setHistory] = useState<Session[]>([]);
  useEffect(() => {
    (async () => {
      if (programme) setPlan(await repo.listPlannedWorkouts(programme.id));
      setHistory(await repo.listSessions(100));
    })();
  }, [programme]);
  const today = localDate();
  const upcoming = plan.filter((w) => w.status !== 'done' && w.status !== 'skipped').slice(0, 14);
  const weekOf = (w: PlannedWorkout) => `Week ${w.week}`;

  return (
    <div className="screen">
      <div className="row between">
        <h1>Workouts</h1>
        <a href="#/exercises" className="btn secondary sm">Exercise library</a>
      </div>
      {inProgress && <button className="btn md" onClick={() => navigate(`/session/${inProgress.id}`)}>Resume: {inProgress.name}</button>}
      {programme && (
        <div className="card">
          <b>{programme.name}</b>
          <span className="small muted">{programme.daysPerWeek} days a week · {programme.weeks} weeks from {programme.startDate} · lighter weeks: {(programme.config.deloadWeeks as number[]).join(', ')}</span>
          <div className="row"><a href="#/reschedule" className="small" style={{ fontWeight: 600 }}>Reschedule or change days</a><span className="muted">·</span><a href="#/review" className="small" style={{ fontWeight: 600 }}>Weekly review</a></div>
        </div>
      )}
      <div className="tabs" role="tablist">
        <button role="tab" aria-selected={tab === 'plan'} className={tab === 'plan' ? 'on' : ''} onClick={() => setTab('plan')}>Upcoming</button>
        <button role="tab" aria-selected={tab === 'history'} className={tab === 'history' ? 'on' : ''} onClick={() => setTab('history')}>History ({history.length})</button>
      </div>
      {tab === 'plan' && (
        <div className="stack">
          {upcoming.length === 0 && <div className="empty">No upcoming sessions. {programme ? 'Block complete.' : 'Build a programme from Profile > Training.'}</div>}
          {upcoming.map((w) => (
            <a key={w.id} href={`#/workout/${w.id}`} className="card row" style={{ color: 'inherit' }}>
              <div className="col" style={{ alignItems: 'center', minWidth: 48 }}>
                <span className="tiny muted">{new Date(w.scheduledDate + 'T00:00').toLocaleDateString([], { weekday: 'short' })}</span>
                <b>{w.scheduledDate.slice(8)}</b>
                <span className="tiny muted">{new Date(w.scheduledDate + 'T00:00').toLocaleDateString([], { month: 'short' })}</span>
              </div>
              <div className="col grow">
                <b style={{ fontSize: 14 }}>{w.name}</b>
                <span className="small muted">{weekOf(w)} · {w.exercises.length} exercises · ~{w.estimatedMinutes} min</span>
              </div>
              {w.scheduledDate < today && w.status !== 'partial' && <span className="pill warn">Missed</span>}
              {w.status === 'partial' && <span className="pill warn">Partial</span>}
              {w.scheduledDate === today && <span className="pill">Today</span>}
              <Icon name="chevron" size={18} color="#475569" />
            </a>
          ))}
        </div>
      )}
      {tab === 'history' && (
        <div className="stack">
          {history.length === 0 && <div className="empty">No completed sessions yet.</div>}
          {history.map((s) => (
            <a key={s.id} href={`#/summary/${s.id}`} className="card row" style={{ color: 'inherit' }}>
              <div className="col grow">
                <b style={{ fontSize: 14 }}>{s.name}</b>
                <span className="small muted">{new Date(s.startedAt).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })} · {s.durationS ? Math.round(s.durationS / 60) + ' min' : '—'}{s.rpe != null ? ` · effort ${s.rpe}/10` : ''}</span>
              </div>
              <span className={'pill ' + (s.status === 'completed' ? 'good' : 'grey')}>{s.status === 'completed' ? 'Done' : 'Ended early'}</span>
            </a>
          ))}
        </div>
      )}
    </div>
  );
}

import { useEffect, useState } from 'react';
import { useApp } from '../app/store';
import * as repo from '../db/repos';
import type { Reminder } from '../db/types';
import { Switch, TopBar } from '../components/ui';
import { getQuietHours, setQuietHours, getAllOff, setAllOff, getStatus, requestPermission, syncSchedule, snooze, type NotificationStatus } from '../notifications/scheduler';
import { planOccurrences, REMINDER_TEXT, type QuietHours } from '../notifications/planner';

const DAYS = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];

export function Reminders() {
  const { toast } = useApp();
  const [list, setList] = useState<Reminder[]>([]);
  const [quiet, setQuiet] = useState<QuietHours>({ enabled: true, start: '22:00', end: '07:00' });
  const [allOff, setAllOffState] = useState(false);
  const [status, setStatus] = useState<NotificationStatus | null>(null);
  const [open, setOpen] = useState<string | null>(null);

  const reload = async () => {
    setList(await repo.listReminders());
    setQuiet(await getQuietHours());
    setAllOffState(await getAllOff());
    setStatus(await getStatus());
  };
  useEffect(() => { void reload(); }, []);

  async function apply() {
    const s = await syncSchedule();
    setStatus(s);
    if (s.supported && s.permission !== 'granted') toast('Notification permission is needed before reminders become active.');
  }
  async function save(r: Reminder) {
    await repo.saveReminder(r);
    setList((xs) => xs.map((x) => (x.id === r.id ? r : x)));
    await apply();
  }
  const planned = planOccurrences(list, quiet, allOff).length;

  return (
    <div className="screen">
      <TopBar title="Reminders" backTo="/profile" />
      <div className={'card ' + (status?.permission === 'granted' ? '' : 'warn')} style={{ gap: 6 }}>
        <b style={{ fontSize: 14 }}>Status</b>
        {!status?.supported && <span className="small">{status?.lastError ?? 'Only available in the Android app.'}</span>}
        {status?.supported && (
          <>
            <span className="small">Permission: {status.permission} · {status.scheduled} notifications scheduled on the device · {planned} planned from your settings{status.exactAlarms === false ? ' · inexact timing (Android may deliver a few minutes late)' : ''}</span>
            {status.permission !== 'granted' && <button className="btn md" onClick={async () => { await requestPermission(); await apply(); }}>Allow notifications</button>}
            {status.lastError && <span className="tiny">{status.lastError}</span>}
          </>
        )}
        <span className="tiny muted">A reminder counts as active only when permission is granted and it appears in the scheduled count. Android battery settings can still delay delivery.</span>
      </div>
      <div className="card row between">
        <div className="col"><b style={{ fontSize: 14 }}>All reminders off</b><span className="tiny muted">Master switch; individual settings are kept.</span></div>
        <Switch on={allOff} onChange={async (v) => { await setAllOff(v); setAllOffState(v); await apply(); }} label="All reminders off" />
      </div>
      <div className="card">
        <div className="row between"><div className="col"><b style={{ fontSize: 14 }}>Quiet hours</b><span className="tiny muted">No reminders in this window</span></div><Switch on={quiet.enabled} onChange={async (v) => { const q = { ...quiet, enabled: v }; setQuiet(q); await setQuietHours(q); await apply(); }} label="Quiet hours" /></div>
        <div className="grid2">
          <div className="field"><label htmlFor="qs">From</label><input id="qs" type="time" className="input" value={quiet.start} onChange={async (e) => { const q = { ...quiet, start: e.target.value }; setQuiet(q); await setQuietHours(q); await apply(); }} /></div>
          <div className="field"><label htmlFor="qe">To</label><input id="qe" type="time" className="input" value={quiet.end} onChange={async (e) => { const q = { ...quiet, end: e.target.value }; setQuiet(q); await setQuietHours(q); await apply(); }} /></div>
        </div>
      </div>
      <div className="card" style={{ padding: '4px 16px' }}>
        {list.map((r) => (
          <div key={r.id} className="col" style={{ borderTop: '1px solid #F1F5F9', padding: '8px 0' }}>
            <div className="row">
              <button className="col grow" style={{ background: 'none', border: 0, textAlign: 'left', cursor: 'pointer', padding: 0 }} onClick={() => setOpen(open === r.id ? null : r.id)}>
                <b style={{ fontSize: 14 }}>{r.label}</b>
                <span className="tiny muted">{r.intervalMinutes ? `every ${r.intervalMinutes} min, ${r.windowStart}–${r.windowEnd}` : r.time} · {r.days.length === 7 ? 'daily' : r.days.map((d) => DAYS[d - 1]).join('')}</span>
              </button>
              <Switch on={r.enabled} onChange={(v) => save({ ...r, enabled: v })} label={r.label} />
            </div>
            {open === r.id && (
              <div className="col" style={{ gap: 8, paddingTop: 8 }}>
                {r.intervalMinutes ? (
                  <div className="grid3">
                    <div className="field"><label htmlFor={'i' + r.id}>Every (min)</label><input id={'i' + r.id} type="number" className="input" value={r.intervalMinutes} onChange={(e) => save({ ...r, intervalMinutes: Math.max(15, Number(e.target.value) || 60) })} /></div>
                    <div className="field"><label htmlFor={'ws' + r.id}>From</label><input id={'ws' + r.id} type="time" className="input" value={r.windowStart ?? '08:00'} onChange={(e) => save({ ...r, windowStart: e.target.value })} /></div>
                    <div className="field"><label htmlFor={'we' + r.id}>To</label><input id={'we' + r.id} type="time" className="input" value={r.windowEnd ?? '21:00'} onChange={(e) => save({ ...r, windowEnd: e.target.value })} /></div>
                  </div>
                ) : (
                  <div className="field"><label htmlFor={'t' + r.id}>Time</label><input id={'t' + r.id} type="time" className="input" value={r.time ?? '09:00'} onChange={(e) => save({ ...r, time: e.target.value })} /></div>
                )}
                <div className="row" style={{ gap: 4 }}>
                  {DAYS.map((d, i) => { const n = i + 1; const on = r.days.includes(n); return <button key={i} className={'choice' + (on ? ' on' : '')} style={{ flex: 1, minHeight: 36, padding: 0, fontSize: 12 }} aria-pressed={on} aria-label={['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][i]} onClick={() => save({ ...r, days: on ? r.days.filter((x) => x !== n) : [...r.days, n].sort() })}>{d}</button>; })}
                </div>
                <button className="btn secondary sm" onClick={async () => { await snooze(r.id, 30, REMINDER_TEXT[r.type].title, REMINDER_TEXT[r.type].body); toast('Snoozed 30 min'); }}>Snooze 30 min (test)</button>
              </div>
            )}
          </div>
        ))}
      </div>
      <button className="btn secondary md" onClick={apply}>Re-sync schedule</button>
    </div>
  );
}

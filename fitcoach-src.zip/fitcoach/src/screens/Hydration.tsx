import { useEffect, useState } from 'react';
import { useApp } from '../app/store';
import * as repo from '../db/repos';
import type { HydrationEntry } from '../db/types';
import { BarChart, Icon, Ring, Sheet, TopBar } from '../components/ui';
import { hydrationTargetMl } from '../engine/targets';
import { addDays, localDate } from '../lib/time';

export function Hydration() {
  const { profile, toast } = useApp();
  const [entries, setEntries] = useState<HydrationEntry[]>([]);
  const [target, setTarget] = useState<number>(hydrationTargetMl(profile).ml);
  const [week, setWeek] = useState<{ date: string; ml: number }[]>([]);
  const [month, setMonth] = useState<{ date: string; ml: number }[]>([]);
  const [undo, setUndo] = useState<{ kind: 'delete' | 'add'; id: string } | null>(null);
  const [customOpen, setCustomOpen] = useState(false);
  const [custom, setCustom] = useState('300');
  const [targetOpen, setTargetOpen] = useState(false);
  const [targetInput, setTargetInput] = useState('');
  const [view, setView] = useState<'today' | 'week' | 'month'>('today');
  const today = localDate();

  const reload = async () => {
    setEntries(await repo.listHydration(today));
    const t = await repo.getSetting('hydration_target_ml');
    if (t) setTarget(Number(t));
    const w = await repo.hydrationDailyTotals(addDays(today, -6), today);
    setWeek(Array.from({ length: 7 }, (_, i) => { const d = addDays(today, -6 + i); return { date: d, ml: w.find((x) => x.date === d)?.ml ?? 0 }; }));
    const m = await repo.hydrationDailyTotals(addDays(today, -29), today);
    setMonth(Array.from({ length: 30 }, (_, i) => { const d = addDays(today, -29 + i); return { date: d, ml: m.find((x) => x.date === d)?.ml ?? 0 }; }));
  };
  useEffect(() => { void reload(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const total = entries.reduce((a, e) => a + e.amountMl, 0);

  async function add(ml: number) {
    if (ml <= 0 || ml > 2000) { toast('Enter between 1 and 2000 ml'); return; }
    const e = await repo.addHydration(ml);
    setUndo({ kind: 'add', id: e.id });
    await reload();
  }
  async function remove(e: HydrationEntry) {
    await repo.deleteHydration(e.id);
    setUndo({ kind: 'delete', id: e.id });
    await reload();
  }
  async function doUndo() {
    if (!undo) return;
    if (undo.kind === 'delete') await repo.undeleteHydration(undo.id);
    else await repo.deleteHydration(undo.id);
    setUndo(null);
    await reload();
  }
  async function edit(e: HydrationEntry) {
    const v = prompt('Amount in ml', String(e.amountMl));
    if (v == null) return;
    const n = Number(v);
    if (!n || Number.isNaN(n)) return;
    await repo.updateHydration(e.id, n);
    await reload();
  }
  async function saveTarget() {
    const n = Number(targetInput);
    if (!n || n < 500 || n > 6000) { toast('Target must be between 500 and 6000 ml'); return; }
    await repo.setSetting('hydration_target_ml', String(n));
    setTargetOpen(false);
    await reload();
  }

  return (
    <div className="screen">
      <TopBar title="Water intake" backTo="/" sub={`Today · ${today} · resets at local midnight`} right={<a href="#/reminders" className="icon-btn" aria-label="Hydration reminders"><Icon name="bell" size={20} /></a>} />
      <div className="card row" style={{ gap: 18 }}>
        <Ring value={total} max={target} label={`${(total / 1000).toFixed(2)} litres of ${(target / 1000).toFixed(1)} litre target`} center={`${(total / 1000).toFixed(1)} L`} sub={`of ${(target / 1000).toFixed(1)} L`} />
        <div className="col grow" style={{ gap: 6 }}>
          <span className="small muted">Remaining</span>
          <span style={{ fontSize: 24, fontWeight: 700 }} aria-live="polite">{total >= target ? 'Target reached' : `${((target - total) / 1000).toFixed(2)} L to go`}</span>
          <button className="btn ghost sm" style={{ justifyContent: 'flex-start', padding: 0 }} onClick={() => { setTargetInput(String(target)); setTargetOpen(true); }}>Adjust target</button>
        </div>
      </div>
      <div className="grid4">
        {[150, 250, 500, 750].map((ml) => <button key={ml} className="choice" onClick={() => add(ml)}>{ml} ml</button>)}
      </div>
      <div className="row">
        <button className="btn md" onClick={() => setCustomOpen(true)}>Add custom amount</button>
        <button className="btn secondary md" style={{ width: 'auto' }} disabled={!undo} onClick={doUndo}>Undo</button>
      </div>
      <div className="tabs" role="tablist">
        {(['today', 'week', 'month'] as const).map((v) => <button key={v} role="tab" aria-selected={view === v} className={view === v ? 'on' : ''} onClick={() => setView(v)}>{v[0].toUpperCase() + v.slice(1)}</button>)}
      </div>
      {view === 'today' && (
        <div className="card">
          <b>Today's log</b>
          {entries.length === 0 && <span className="small muted">Nothing logged yet today.</span>}
          {entries.map((e) => (
            <div key={e.id} className="list-item">
              <Icon name="drop" size={18} color="#1D6AE5" />
              <span className="grow small muted">{new Date(e.loggedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
              <button className="btn ghost sm" style={{ color: 'var(--ink)', fontWeight: 600 }} onClick={() => edit(e)}>{e.amountMl} ml</button>
              <button className="icon-btn ghost" aria-label="Delete entry" onClick={() => remove(e)}><Icon name="trash" size={18} color="#475569" /></button>
            </div>
          ))}
        </div>
      )}
      {view === 'week' && (
        <div className="card">
          <b>Last 7 days</b>
          <BarChart bars={week.map((d) => ({ x: new Date(d.date + 'T00:00').toLocaleDateString([], { weekday: 'narrow' }), y: Math.round(d.ml / 100) / 10 }))} target={target / 1000} label="Daily water intake, last 7 days" unit="L" />
          <span className="small muted">Average {(week.reduce((a, d) => a + d.ml, 0) / 7 / 1000).toFixed(1)} L · target met {week.filter((d) => d.ml >= target).length} of 7 days</span>
        </div>
      )}
      {view === 'month' && (
        <div className="card">
          <b>Last 30 days</b>
          <BarChart bars={month.map((d) => ({ x: d.date.endsWith('01') || d.date === today ? d.date.slice(8) : '', y: Math.round(d.ml / 100) / 10 }))} target={target / 1000} label="Daily water intake, last 30 days" unit="L" />
          <span className="small muted">Average {(month.reduce((a, d) => a + d.ml, 0) / 30 / 1000).toFixed(1)} L · target met {month.filter((d) => d.ml >= target).length} of 30 days</span>
        </div>
      )}
      <span className="tiny muted">{hydrationTargetMl(profile).note} Missing entries are not treated as dehydration.</span>

      <Sheet open={customOpen} onClose={() => setCustomOpen(false)} title="Custom amount">
        <input className="input" type="number" inputMode="numeric" aria-label="Millilitres" value={custom} onChange={(e) => setCustom(e.target.value)} />
        <button className="btn" onClick={async () => { await add(Number(custom)); setCustomOpen(false); }}>Add {custom} ml</button>
      </Sheet>
      <Sheet open={targetOpen} onClose={() => setTargetOpen(false)} title="Daily target">
        <p className="small muted">Starting estimate: {hydrationTargetMl(profile).ml} ml. {hydrationTargetMl(profile).note}</p>
        <input className="input" type="number" inputMode="numeric" aria-label="Target in ml" value={targetInput} onChange={(e) => setTargetInput(e.target.value)} />
        <button className="btn" onClick={saveTarget}>Save target</button>
      </Sheet>
    </div>
  );
}

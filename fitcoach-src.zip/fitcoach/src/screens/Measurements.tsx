import { useEffect, useState } from 'react';
import { useApp } from '../app/store';
import * as repo from '../db/repos';
import type { Measurement } from '../db/types';
import { Icon, TopBar } from '../components/ui';
import { localDate } from '../lib/time';

const TYPES: { id: string; label: string; unit: string }[] = [
  { id: 'weight', label: 'Weight', unit: 'kg' }, { id: 'waist', label: 'Waist', unit: 'cm' }, { id: 'chest', label: 'Chest', unit: 'cm' },
  { id: 'arm', label: 'Arm', unit: 'cm' }, { id: 'thigh', label: 'Thigh', unit: 'cm' }, { id: 'hips', label: 'Hips', unit: 'cm' }, { id: 'neck', label: 'Neck', unit: 'cm' },
];

export function Measurements() {
  const { toast, refresh } = useApp();
  const [type, setType] = useState('weight');
  const [custom, setCustom] = useState('');
  const [value, setValue] = useState('');
  const [date, setDate] = useState(localDate());
  const [note, setNote] = useState('');
  const [list, setList] = useState<Measurement[]>([]);
  const t = TYPES.find((x) => x.id === type);
  const unit = t?.unit ?? 'cm';

  const reload = async () => setList(await repo.listMeasurements(undefined, 100));
  useEffect(() => { void reload(); }, []);

  async function add() {
    const v = Number(value);
    if (!v || Number.isNaN(v)) { toast('Enter a value'); return; }
    const typeId = type === 'custom' ? custom.trim().toLowerCase() : type;
    if (!typeId) { toast('Name the custom measurement'); return; }
    await repo.addMeasurement({ type: typeId, value: v, unit, note: note || null, localDate: date });
    if (typeId === 'weight' && date === localDate()) await repo.saveProfile({ weightKg: v });
    setValue(''); setNote('');
    await reload(); await refresh();
    toast('Saved');
  }

  async function edit(m: Measurement) {
    const nv = prompt(`New value for ${m.type} (${m.unit})`, String(m.value));
    if (nv == null) return;
    const v = Number(nv);
    if (Number.isNaN(v)) return;
    await repo.updateMeasurement(m.id, v, m.note);
    await reload();
  }

  async function del(m: Measurement) {
    if (!confirm(`Delete ${m.type} ${m.value} ${m.unit} on ${m.localDate}?`)) return;
    await repo.deleteMeasurement(m.id);
    await reload();
  }

  return (
    <div className="screen">
      <TopBar title="Body measurements" backTo="/progress" />
      <div className="card">
        <div className="row" style={{ flexWrap: 'wrap', gap: 6 }}>
          {TYPES.map((x) => <button key={x.id} className={'choice' + (type === x.id ? ' on' : '')} style={{ minHeight: 38, fontSize: 13, padding: '0 10px' }} aria-pressed={type === x.id} onClick={() => setType(x.id)}>{x.label}</button>)}
          <button className={'choice' + (type === 'custom' ? ' on' : '')} style={{ minHeight: 38, fontSize: 13, padding: '0 10px' }} aria-pressed={type === 'custom'} onClick={() => setType('custom')}>Custom</button>
        </div>
        {type === 'custom' && <input className="input" aria-label="Custom measurement name" placeholder="e.g. calf" value={custom} onChange={(e) => setCustom(e.target.value)} />}
        <div className="grid2">
          <div className="field"><label htmlFor="mv">Value ({unit})</label><input id="mv" className="input" type="number" inputMode="decimal" value={value} onChange={(e) => setValue(e.target.value)} /></div>
          <div className="field"><label htmlFor="md">Date</label><input id="md" className="input" type="date" value={date} max={localDate()} onChange={(e) => setDate(e.target.value)} /></div>
        </div>
        <input className="input" aria-label="Note" placeholder="Note (optional, e.g. morning, fasted)" value={note} onChange={(e) => setNote(e.target.value)} />
        <button className="btn md" onClick={add}><Icon name="plus" size={18} />Save measurement</button>
        <span className="tiny muted">Measure at the same time of day under the same conditions for comparable trends. Progress photos can be kept in your phone's gallery; this app does not upload anything.</span>
      </div>
      <div className="card">
        <b>Recent entries</b>
        {list.length === 0 && <span className="small muted">Nothing recorded yet.</span>}
        {list.map((m) => (
          <div key={m.id} className="list-item">
            <div className="col grow"><b style={{ fontSize: 14, textTransform: 'capitalize' }}>{m.type}: {m.value} {m.unit}</b><span className="tiny muted">{m.localDate}{m.note ? ` · ${m.note}` : ''}</span></div>
            <button className="icon-btn ghost" aria-label="Edit" onClick={() => edit(m)}><Icon name="ruler" size={18} /></button>
            <button className="icon-btn ghost" aria-label="Delete" onClick={() => del(m)}><Icon name="trash" size={18} /></button>
          </div>
        ))}
      </div>
    </div>
  );
}

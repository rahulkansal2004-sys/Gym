import { useState } from 'react';
import { useApp } from '../app/store';
import * as repo from '../db/repos';
import type { Profile, GoalId } from '../db/types';
import type { Equipment, BodyArea } from '../data/exercises';
import { GOAL_INFO } from '../engine/programme';
import { createProgrammeFromProfile } from '../app/services';
import { Icon } from '../components/ui';
import { navigate } from '../lib/router';

const EQUIPMENT_PRESETS: { id: string; label: string; items: Equipment[] }[] = [
  { id: 'gym', label: 'Full gym', items: ['barbell', 'dumbbell', 'cable', 'machine', 'bench', 'pull-up-bar', 'kettlebell', 'cardio-machine', 'band'] },
  { id: 'home', label: 'Home: dumbbells and bands', items: ['dumbbell', 'band', 'bench'] },
  { id: 'body', label: 'Bodyweight only', items: [] },
];
const AREAS: BodyArea[] = ['knee', 'lower-back', 'shoulder', 'wrist', 'elbow', 'hip', 'neck', 'ankle'];
const EXPERIENCE: [Profile['experience'], string][] = [['new', 'Complete beginner'], ['beginner-some', 'Beginner with some experience'], ['intermediate', 'Intermediate'], ['advanced', 'Advanced'], ['unsure', 'Unsure, help me assess my level']];
const GOALS = Object.keys(GOAL_INFO) as GoalId[];

export function Onboarding() {
  const { refresh, toast } = useApp();
  const [step, setStep] = useState(0);
  const [p, setP] = useState<Partial<Profile>>({ experience: 'beginner-some', activityLevel: 'light', daysPerWeek: 3, sessionMinutes: 45, equipment: [], location: 'home', diet: 'vegetarian', restrictions: [], sex: null });
  const [preset, setPreset] = useState('home');
  const [primary, setPrimary] = useState<GoalId | null>(null);
  const [secondary, setSecondary] = useState<GoalId | null>(null);
  const [customText, setCustomText] = useState('');
  const [busy, setBusy] = useState(false);
  const [warnings, setWarnings] = useState<string[]>([]);
  const set = (patch: Partial<Profile>) => setP((x) => ({ ...x, ...patch }));
  const steps = ['Welcome', 'Your profile', 'Your goal', 'Training', 'Health', 'Done'];

  async function finish() {
    setBusy(true);
    try {
      const profile = await repo.saveProfile({ ...p, equipment: EQUIPMENT_PRESETS.find((e) => e.id === preset)!.items, timezone: Intl.DateTimeFormat().resolvedOptions().timeZone, restrictionsConfirmedAt: new Date().toISOString(), onboardingComplete: true });
      await repo.setGoal(primary ?? 'general-health', secondary, primary === 'custom' ? customText : null);
      const r = await createProgrammeFromProfile(profile, primary ?? 'general-health');
      setWarnings(r.warnings);
      setStep(5); // store refresh happens on "Go to home" so this screen stays visible
    } catch (e) {
      toast('Could not finish setup: ' + (e as Error).message);
    } finally { setBusy(false); }
  }

  const canNextProfile = !!p.heightCm && !!p.weightKg;

  return (
    <div className="screen no-tabs">
      {step > 0 && step < 5 && (
        <div className="topbar">
          <button className="icon-btn" aria-label="Back" onClick={() => setStep(step - 1)}><Icon name="back" /></button>
          <div className="grow col">
            <h1>{steps[step]}</h1>
            <div className="row">
              <div className="progress grow" role="progressbar" aria-valuenow={step} aria-valuemin={0} aria-valuemax={4}><div style={{ width: `${(step / 4) * 100}%` }} /></div>
              <span className="small muted">{step} / 4</span>
            </div>
          </div>
        </div>
      )}

      {step === 0 && (
        <>
          <div className="col" style={{ alignItems: 'center', textAlign: 'center', gap: 10, paddingTop: 40 }}>
            <div className="icon-box" style={{ width: 56, height: 56, background: 'var(--blue)', color: '#fff' }}><Icon name="dumbbell" size={30} /></div>
            <h1 style={{ fontSize: 28, lineHeight: '34px' }}>Welcome to your fitness coach</h1>
            <p className="muted" style={{ fontSize: 15, lineHeight: '22px' }}>A personalised programme that adapts to what you actually log. Everything stays on this phone.</p>
          </div>
          <div className="card" style={{ marginTop: 'auto' }}>
            <div className="row"><Icon name="sparkle" color="#1D6AE5" /><div className="col"><b>Personalised plan</b><span className="small muted">Built from your goal, time and equipment</span></div></div>
            <div className="row"><Icon name="chart" color="#1D6AE5" /><div className="col"><b>Real progress</b><span className="small muted">Every set, drink and measurement, charted</span></div></div>
            <div className="row"><Icon name="shield" color="#1D6AE5" /><div className="col"><b>Private by design</b><span className="small muted">No account, no cloud. Local database on your phone</span></div></div>
          </div>
          <button className="btn" onClick={() => setStep(1)}>Get started</button>
        </>
      )}

      {step === 1 && (
        <>
          <p className="small muted">Only height and weight are needed to build a plan. Everything else is optional and editable later.</p>
          <div className="field"><label htmlFor="name">Name (optional)</label><input id="name" className="input" value={p.name ?? ''} onChange={(e) => set({ name: e.target.value })} /></div>
          <div className="field"><label htmlFor="dob">Date of birth (optional, for calorie estimates)</label><input id="dob" type="date" className="input" value={p.dob ?? ''} onChange={(e) => set({ dob: e.target.value || null })} /></div>
          <div className="grid2">
            <div className="field"><label htmlFor="h">Height (cm)</label><input id="h" type="number" inputMode="decimal" className="input" value={p.heightCm ?? ''} onChange={(e) => set({ heightCm: e.target.value ? Number(e.target.value) : null })} /></div>
            <div className="field"><label htmlFor="w">Weight (kg)</label><input id="w" type="number" inputMode="decimal" className="input" value={p.weightKg ?? ''} onChange={(e) => set({ weightKg: e.target.value ? Number(e.target.value) : null })} /></div>
          </div>
          <div className="grid2">
            <div className="field"><label htmlFor="tw">Target weight (optional)</label><input id="tw" type="number" inputMode="decimal" className="input" placeholder="kg" value={p.targetWeightKg ?? ''} onChange={(e) => set({ targetWeightKg: e.target.value ? Number(e.target.value) : null })} /></div>
            <div className="field"><label htmlFor="wa">Waist (optional)</label><input id="wa" type="number" inputMode="decimal" className="input" placeholder="cm" value={p.waistCm ?? ''} onChange={(e) => set({ waistCm: e.target.value ? Number(e.target.value) : null })} /></div>
          </div>
          <fieldset style={{ border: 0, padding: 0, margin: 0 }} className="field">
            <legend style={{ padding: 0, fontSize: 13, fontWeight: 600, marginBottom: 6 }}>Sex <span className="muted" style={{ fontWeight: 400 }}>(optional, only used for calorie estimates)</span></legend>
            <div className="grid3">
              {([['male', 'Male'], ['female', 'Female'], ['unspecified', 'Prefer not to say']] as const).map(([id, l]) => (
                <button key={id} type="button" className={'choice' + (p.sex === id ? ' on' : '')} aria-pressed={p.sex === id} onClick={() => set({ sex: id })}>{l}</button>
              ))}
            </div>
          </fieldset>
          <fieldset style={{ border: 0, padding: 0, margin: 0 }} className="field">
            <legend style={{ padding: 0, fontSize: 13, fontWeight: 600, marginBottom: 6 }}>Training experience</legend>
            <div className="stack">
              {EXPERIENCE.map(([id, l]) => (
                <button key={id} type="button" className={'choice left' + (p.experience === id ? ' on' : '')} aria-pressed={p.experience === id} onClick={() => set({ experience: id })}>{l}</button>
              ))}
            </div>
            {p.experience === 'unsure' && <p className="small muted">We will start you on a beginner-friendly plan; progress is reviewed weekly from your logs.</p>}
          </fieldset>
          <button className="btn" disabled={!canNextProfile} onClick={() => setStep(2)}>Next</button>
        </>
      )}

      {step === 2 && (
        <>
          <p className="small muted">Pick one primary goal. Tap a second card for an optional secondary goal. These shape your plan; they are not promises about appearance.</p>
          <div className="stack">
            {GOALS.map((g) => {
              const isP = primary === g, isS = secondary === g;
              return (
                <button key={g} type="button" className={'choice left' + (isP ? ' on' : isS ? ' secondary-on' : '')} aria-pressed={isP || isS} style={{ minHeight: 64, padding: '10px 12px' }}
                  onClick={() => { if (isP) return; if (isS) { setSecondary(null); return; } if (!primary) setPrimary(g); else setSecondary(g); }}>
                  <div className="col grow" style={{ textAlign: 'left' }}>
                    <span style={{ fontWeight: 600, color: 'var(--ink)' }}>{GOAL_INFO[g].label}</span>
                    <span className="small muted">{GOAL_INFO[g].blurb}</span>
                  </div>
                  <span className="tiny" style={{ color: 'var(--blue)', fontWeight: 600, minWidth: 64, textAlign: 'right' }}>{isP ? 'Primary' : isS ? 'Secondary' : ''}</span>
                </button>
              );
            })}
          </div>
          {primary === 'custom' && <div className="field"><label htmlFor="custom">Describe your goal</label><input id="custom" className="input" value={customText} onChange={(e) => setCustomText(e.target.value)} placeholder="e.g. climb stairs without getting winded" /></div>}
          {primary && <button className="btn ghost sm" onClick={() => { setPrimary(null); setSecondary(null); }}>Clear selection</button>}
          <button className="btn" disabled={!primary} onClick={() => setStep(3)}>Next</button>
        </>
      )}

      {step === 3 && (
        <>
          <fieldset style={{ border: 0, padding: 0, margin: 0 }} className="field">
            <legend style={{ padding: 0, fontSize: 14, fontWeight: 600, marginBottom: 8 }}>How many days per week?</legend>
            <div className="grid5">
              {[2, 3, 4, 5, 6].map((n) => <button key={n} type="button" className={'choice' + (p.daysPerWeek === n ? ' on' : '')} aria-pressed={p.daysPerWeek === n} onClick={() => set({ daysPerWeek: n })}>{n}</button>)}
            </div>
            <p className="small muted">{({ 2: 'Two full-body sessions.', 3: 'Three full-body sessions, well spaced.', 4: 'Upper / lower split, two of each.', 5: 'Hybrid split with a conditioning day.', 6: 'Six days is only suggested for experienced lifters.' } as Record<number, string>)[p.daysPerWeek ?? 3]}</p>
          </fieldset>
          <fieldset style={{ border: 0, padding: 0, margin: 0 }} className="field">
            <legend style={{ padding: 0, fontSize: 14, fontWeight: 600, marginBottom: 8 }}>Preferred session duration</legend>
            <div className="grid4">
              {[30, 45, 60, 75].map((n) => <button key={n} type="button" className={'choice' + (p.sessionMinutes === n ? ' on' : '')} aria-pressed={p.sessionMinutes === n} onClick={() => set({ sessionMinutes: n })}>{n} min</button>)}
            </div>
          </fieldset>
          <fieldset style={{ border: 0, padding: 0, margin: 0 }} className="field">
            <legend style={{ padding: 0, fontSize: 14, fontWeight: 600, marginBottom: 8 }}>Available equipment</legend>
            <div className="stack">
              {EQUIPMENT_PRESETS.map((e) => (
                <button key={e.id} type="button" className={'choice left' + (preset === e.id ? ' on' : '')} aria-pressed={preset === e.id} onClick={() => { setPreset(e.id); set({ location: e.id === 'gym' ? 'gym' : 'home' }); }}>
                  <span className="grow">{e.label}</span>{preset === e.id && <Icon name="check" size={20} />}
                </button>
              ))}
            </div>
            <p className="small muted">You can fine-tune individual items in Profile later.</p>
          </fieldset>
          <fieldset style={{ border: 0, padding: 0, margin: 0 }} className="field">
            <legend style={{ padding: 0, fontSize: 14, fontWeight: 600, marginBottom: 8 }}>Current activity level (outside training)</legend>
            <select className="input" aria-label="Activity level" value={p.activityLevel} onChange={(e) => set({ activityLevel: e.target.value as Profile['activityLevel'] })}>
              <option value="sedentary">Sedentary (desk, little walking)</option>
              <option value="light">Light (some walking)</option>
              <option value="moderate">Moderate (on feet much of the day)</option>
              <option value="active">Active (physical job)</option>
              <option value="very-active">Very active</option>
            </select>
          </fieldset>
          <button className="btn" onClick={() => setStep(4)}>Next</button>
        </>
      )}

      {step === 4 && (
        <>
          <fieldset style={{ border: 0, padding: 0, margin: 0 }} className="field">
            <legend style={{ padding: 0, fontSize: 14, fontWeight: 600, marginBottom: 8 }}>Any injuries, pain or areas to avoid loading?</legend>
            <div className="grid4">
              {AREAS.map((a) => {
                const on = p.restrictions?.includes(a);
                return <button key={a} type="button" className={'choice' + (on ? ' on' : '')} aria-pressed={on} style={{ minHeight: 44, fontSize: 13, padding: '0 6px' }} onClick={() => set({ restrictions: on ? p.restrictions!.filter((x) => x !== a) : [...(p.restrictions ?? []), a] })}>{a.replace('-', ' ')}</button>;
              })}
            </div>
            <input className="input" aria-label="Restriction notes" placeholder="Notes, e.g. left knee hurts on deep squats" value={p.restrictionNotes ?? ''} onChange={(e) => set({ restrictionNotes: e.target.value || null })} />
            <p className="small muted">Used to avoid conflicting exercises. The app is a fitness tool, not medical advice; if you have a medical condition, check with your doctor before starting.</p>
          </fieldset>
          <div className="field">
            <label htmlFor="diet">Diet preference</label>
            <select id="diet" className="input" value={p.diet} onChange={(e) => set({ diet: e.target.value as Profile['diet'] })}>
              <option value="vegetarian">Vegetarian (includes dairy)</option>
              <option value="eggetarian">Vegetarian + eggs</option>
              <option value="non-vegetarian">Non-vegetarian</option>
              <option value="vegan">Vegan</option>
            </select>
          </div>
          <div className="field"><label htmlFor="sleep">Average sleep per night (hours, optional)</label><input id="sleep" type="number" inputMode="decimal" className="input" value={p.sleepHours ?? ''} onChange={(e) => set({ sleepHours: e.target.value ? Number(e.target.value) : null })} /></div>
          <label className="row card flat" style={{ cursor: 'pointer' }}>
            <input type="checkbox" checked={!!p.excludeGluteIsolation} onChange={(e) => set({ excludeGluteIsolation: e.target.checked })} />
            <span className="grow small">Skip dedicated glute-isolation exercises (hip thrusts, kickbacks). Lower-body balance is kept through squats, hinges and lunges.</span>
          </label>
          <button className="btn" disabled={busy} onClick={finish}>{busy ? 'Building your plan…' : 'Build my programme'}</button>
        </>
      )}

      {step === 5 && (
        <>
          <div className="col" style={{ alignItems: 'center', textAlign: 'center', gap: 10, paddingTop: 40 }}>
            <div className="icon-box" style={{ width: 56, height: 56, background: 'var(--blue)', color: '#fff', borderRadius: 28 }}><Icon name="check" size={30} /></div>
            <h1>You're all set</h1>
            <p className="muted">Your 12-week programme is ready. Nothing is counted as done until you log it.</p>
          </div>
          {warnings.map((w, i) => <div key={i} className="card warn small">{w}</div>)}
          <div className="card">
            <div className="row"><Icon name="check" color="#1D6AE5" size={18} /><span>Profile saved locally</span></div>
            <div className="row"><Icon name="check" color="#1D6AE5" size={18} /><span>Goal selected</span></div>
            <div className="row"><Icon name="check" color="#1D6AE5" size={18} /><span>Training plan generated</span></div>
            <div className="row"><Icon name="info" color="#475569" size={18} /><span className="small muted">Reminders, AI coach and Health Connect are optional: set them up from Profile.</span></div>
          </div>
          <button className="btn" style={{ marginTop: 'auto' }} onClick={async () => { await refresh(); navigate('/', true); }}>Go to home</button>
        </>
      )}
    </div>
  );
}

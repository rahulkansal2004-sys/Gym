#!/usr/bin/env bash
# Builds the debug APK. Needs: Node 18+, JDK 17 or 21, Android SDK (ANDROID_HOME or ANDROID_SDK_ROOT set,
# with platform-tools, platforms;android-36 and build-tools;36.0.0 installed - Android Studio does this for you).
set -euo pipefail
cd "$(dirname "$0")/.."

if [ -z "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}" ]; then
  echo "ANDROID_HOME is not set. Install Android Studio (or the command-line tools) and set ANDROID_HOME, e.g."
  echo "  export ANDROID_HOME=\$HOME/Android/Sdk   (Linux)   |   \$HOME/Library/Android/sdk (macOS)   |   %LOCALAPPDATA%\\Android\\Sdk (Windows)"
  exit 1
fi

echo "== 1/4 install dependencies"; npm ci
echo "== 2/4 run tests"; npm test
echo "== 3/4 build web bundle and sync into the Android project"; npm run build && npx cap sync android
echo "== 4/4 gradle assembleDebug"; (cd android && chmod +x gradlew && ./gradlew assembleDebug)

APK=android/app/build/outputs/apk/debug/app-debug.apk
echo
echo "APK: $(pwd)/$APK ($(du -h "$APK" | cut -f1))"
echo "Install on a connected phone with USB debugging:  adb install -r $APK"
echo "Or copy the file to the phone and open it (allow 'install unknown apps' for your file manager)."

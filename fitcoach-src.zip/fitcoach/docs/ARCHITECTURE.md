# Architecture

## Decision

**Capacitor 8 (native Android shell) + React 19 / TypeScript + native SQLite**, packaged as a real APK.

Why not a PWA: the brief needs a local database that is not IndexedDB, reliable local notifications, Health Connect
access and an installable APK. A PWA cannot provide any of those on Android. Why not pure Kotlin: the UI, engines and
tests are shared with a browser preview (used for automated end-to-end tests), the same code base can later target iOS
(HealthKit) with the same Capacitor plugins, and a cloud backend can be added without rewriting screens. Trade-off: the
WebView UI is slightly less "native" than Compose, and plugins are third-party (`@capacitor-community/sqlite`,
`capacitor-health`).

## Layers

```
screens/ (React)  ──►  app/services.ts  ──►  db/repos.ts  ──►  SqlDriver (native.ts on Android | sqljs.ts in browser/tests)
        │                    │
        │                    └──►  engine/* (pure, deterministic, unit-tested)
        ├──►  ai/coach.ts ──► ai/gemini.ts ──► (proxy on your PC | Gemini directly)   [optional, online]
        ├──►  notifications/planner.ts (pure) ──► scheduler.ts ──► @capacitor/local-notifications
        └──►  wearables/healthConnect.ts ──► capacitor-health ──► Android Health Connect
```

* **Deterministic engines own every number.** Programme generation, load suggestions, PR detection, rescheduling,
  shortening and the weekly review are pure functions with tests. The AI only explains or proposes.
* **Data stays local.** `SqlDriver` is the only persistence path; `exportJson()` gives the user everything.
* **Offline by construction.** No screen fetches anything except `ai/gemini.ts`, which checks `navigator.onLine` and
  degrades to deterministic text.

## Data model (SQLite, `src/db/schema.ts`)

`settings`, `profile` (single row), `goals` (history, one active), `exercises` and `foods` (seeded JSON, `is_custom`
flag), `programmes` → `planned_workouts` (exercises as JSON with sets/reps/rest/role), `sessions` → `exercise_logs` →
`set_logs` (one row per set; `completed` is the only thing that counts), `personal_records`, `nutrition_entries`,
`saved_meals`, `hydration_entries` (`local_date` + `tz_offset_min`, soft delete for undo), `measurements`,
`progress_photos` (table present, UI not built), `recovery_entries`, `reminders`, `wearable_connections`,
`wearable_samples` (UNIQUE provider+type+start+source for dedupe), `sync_history`, `ai_log`, `improvement_requests`,
`programme_reviews`, `audit`.

Timestamps are ISO UTC; daily aggregates use `local_date` captured at logging time so day boundaries follow the user's
calendar even if the time zone changes. Migrations are versioned and append-only; reference content is re-seeded by
`content_version` without touching custom rows.

## Workout session reliability

Every completed set is written immediately. The session's transient state (current exercise, rest timer end time,
draft inputs) is saved to `sessions.state_json` on every change, so killing the app and reopening resumes exactly where
you were (verified by the e2e reload test). Sets logged before an exercise swap stay with the original exercise; the
substitute becomes a new entry so variations are never merged.

## Adding a backend later

`repos.ts` is the seam: add a sync queue table (`pending_ops`) written alongside each repo mutation, a `sync/` module
that pushes/pulls against an API, and conflict rules (last-writer-wins per row with server timestamps, never deleting
unsynced local rows). Screens do not change. Auth would wrap the API client, not the app.

# Wearables and health platforms

Verified against the plugin actually used (`capacitor-health` 8.4.0) and current provider programmes.

| Provider | Status in this build | What it needs | Notes |
|---|---|---|---|
| **Android Health Connect** | Implemented (steps/day, active calories/day, recorded workouts, weight readings) | Health Connect app (built into Android 14+, Play Store on 9–13); user grants each category | Permission flow, selective categories, manual sync, incremental sync with 2-day overlap, dedupe by (type, start, source), sync history, disconnect deletes synced copies. History limited by Health Connect to 30 days before first consent. **Sleep and resting heart rate are not exposed by this plugin** and are shown as unavailable, never estimated. |
| Samsung Health | Via Health Connect | Enable "Health Connect" sync inside Samsung Health | Samsung's own SDK requires partner approval; not needed. |
| Google Fit, Pixel Watch, most Wear OS apps | Via Health Connect | — | Google Fit APIs are deprecated in favour of Health Connect. |
| Fitbit | Not implemented | Fitbit Web API: registered app, OAuth 2.0 with PKCE, a redirect URI the phone can open, token refresh | Feasible without a server using a custom URL scheme, but needs a developer app registration and was out of scope for this offline build. Recent Fitbit versions can also write to Health Connect. |
| Garmin | Not implemented | Garmin Health API: developer-programme approval and a webhook server to receive pushes | Not possible as a pure on-device, zero-cost integration. Garmin Connect can share steps/sleep to Health Connect. |
| Apple Health | Not applicable | iOS build with HealthKit entitlement (the same plugin supports it) | Needs a Mac, Xcode and the iOS target; not part of the Android APK. |

## Permissions declared

Only `READ_STEPS`, `READ_ACTIVE_CALORIES_BURNED`, `READ_EXERCISE`, `READ_WEIGHT` (plus the rationale activity required
by Health Connect). Add more only when a screen uses them, because Health Connect shows every declared permission on
the consent screen.

## How tracker data is used

* Steps and active calories on Home and Progress › Activity, labelled "Health Connect".
* Recorded workouts are listed per day; they are not merged with the app's own sessions (no duplicate counting).
* Weight readings from the tracker are kept in `wearable_samples`; the app's weight chart uses only measurements the
  user entered, so the source is always clear. (Importing tracker weights into measurements is a possible follow-up.)
* Nothing from a tracker changes a training load on its own.

## Testing status

The Health Connect code path compiles against the plugin's TypeScript API but could **not** be exercised here (no
Android device or emulator in the build environment). Test on the phone: Profile › Connected devices › Connect, grant a
subset of categories, Sync now, check Progress › Activity, then revoke in the Health Connect app and confirm the next
sync reports the error and the status flips to `error`.

# Building and installing the APK

The web layer, database, engines and tests build and run anywhere with Node 22. Producing the `.apk` additionally
needs the Android SDK and Gradle's Android plugin, which Google serves from `dl.google.com` / `maven.google.com`.
Those hosts were blocked in the environment this project was written in, so the APK was **not** compiled there
(see `TEST-REPORT.md`). Three ways to get it:

## A. Your computer with Android Studio (most common)

1. Install Android Studio (free). On first run let it install the SDK (platform 36, build-tools, platform-tools).
2. Install Node 22 and JDK 21 (Android Studio bundles a JDK you can point `JAVA_HOME` at).
3. Set `ANDROID_HOME` (Linux: `~/Android/Sdk`, macOS: `~/Library/Android/sdk`, Windows: `%LOCALAPPDATA%\Android\Sdk`).
4. In the project folder:
   ```bash
   ./scripts/build-apk.sh          # Windows: run the steps inside it from Git Bash, or use Android Studio's Build menu
   ```
   or open `android/` in Android Studio and choose **Build › Build Bundle(s) / APK(s) › Build APK(s)**.
5. Output: `android/app/build/outputs/apk/debug/app-debug.apk`.

## B. GitHub Actions (no Android install, free for personal repos)

1. Create a private GitHub repository and push this folder (`.gitignore` already excludes `node_modules`, `dist`, builds and `.env`).
2. Open the repo's **Actions** tab → **Android APK** → **Run workflow** (it also runs on every push to `main`).
3. When it finishes, download the `fitcoach-debug-apk` artifact and unzip it to get `app-debug.apk`.

The workflow (`.github/workflows/android-apk.yml`) runs the unit tests, builds the web bundle, syncs Capacitor and runs
`gradlew assembleDebug` on an Ubuntu runner with the Android SDK preinstalled.

## C. Any machine with the command-line SDK only

```bash
# Linux example
mkdir -p ~/android-sdk/cmdline-tools && cd ~/android-sdk/cmdline-tools
curl -LO https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
unzip commandlinetools-linux-*.zip && mv cmdline-tools latest
export ANDROID_HOME=~/android-sdk; export PATH=$ANDROID_HOME/cmdline-tools/latest/bin:$PATH
yes | sdkmanager --licenses
sdkmanager "platform-tools" "platforms;android-36" "build-tools;36.0.0"
cd /path/to/fitcoach && ./scripts/build-apk.sh
```

## Installing on your phone

* **USB:** enable Developer options › USB debugging, then `adb install -r android/app/build/outputs/apk/debug/app-debug.apk`.
* **File copy:** send `app-debug.apk` to the phone (USB, Drive, email), open it from Files, and allow "Install unknown
  apps" for that app when Android asks. Play Protect may warn because the APK is a debug build signed with a debug
  key: choose "Install anyway".
* Updating: install the new APK over the old one (same `applicationId` `com.chirag.fitcoach`, same debug key) and your
  data is kept. Uninstalling deletes the database.

Minimum Android 7.0 (API 24). Health Connect requires Android 9+ with the Health Connect app (built into Android 14+).

## First run checklist

1. Finish onboarding (height and weight are the only required fields).
2. Profile › Reminders › **Allow notifications** (Android 13+ asks), enable the ones you want.
3. Profile › Connected devices › **Connect** to grant Health Connect categories (optional).
4. Profile › AI coach: choose proxy or direct, **Test connection** (optional; see `GEMINI.md`).

## Release builds and Play Store (later)

Create a keystore, add `signingConfigs.release` in `android/app/build.gradle`, run `./gradlew bundleRelease`. Play requires
a privacy policy and Health Connect declaration form for the health permissions. Not needed for personal sideloading.

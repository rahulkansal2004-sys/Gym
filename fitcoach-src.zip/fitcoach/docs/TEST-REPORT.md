# Test report — 29 Oct 2026

Environment: Linux cloud sandbox, Node 22.23, Chromium (Playwright). No Android device, emulator or SDK available;
`dl.google.com`, `maven.google.com`, `repo1.maven.org`, `plugins.gradle.org` blocked by organisation policy.

## Automated unit tests — `npm test` (vitest, sql.js in memory): 35 / 35 PASS

| Suite | Tests | Status | Covers |
|---|---|---|---|
| `tests/db.test.ts` | 8 | PASS | migrations + idempotent seeding (92 exercises, 145 foods), profile round-trip and weight→measurement, goal history, hydration add/edit/delete/undo and **local-date boundary** (23:50 vs 00:10 next day), nutrition edit + totals, reminder defaults/save, delete-all keeps reference content |
| `tests/engine.test.ts` | 21 | PASS | 4-day upper/lower 12-week block (48 sessions, one per day, all 6 patterns, ≤ duration), bodyweight-only beginner (36 sessions, no advanced moves, ≤ 35 min, pull fallback), knee restriction + glute-isolation exclusion, six-day warning, strength scheme, equipment/difficulty filter; progression: no increase after one session, +2.5/+5 kg only when all sets hit top, hold on high effort, decrease after two poor sessions, bodyweight never gets kg, e1RM band; PR detection (heaviest, e1RM, most-reps) without duplicates; substitution fits equipment and avoids reported area; red-flag triage; reschedule-forward never doubles a day, skip keeps dates, shorten keeps mains and explains cuts; weekly review adherence/trend/recommendation/data gaps; calorie and hydration targets |
| `tests/notifications.test.ts` | 6 | PASS | quiet hours across midnight, interval expansion within window, stable unique ids, disabled/master-off, no duplicate slot per type, weekday mapping |

## End-to-end — `node tests/e2e/smoke.mjs` on the production web build at 390×844: 17 / 17 PASS

Screenshots in `tests/e2e/out/*.png`, results in `tests/e2e/out/results.json`.

1. App boots and shows onboarding
2. Onboarding: profile, goal (primary + secondary), training (4 days, 60 min, full gym), health (knee) → programme built
3. Home shows today's workout and water card
4. Workout preview lists ≥ 4 exercises and **no knee-loading exercise**
5. "Less time?" sheet explains cuts for 30 min
6. Start workout, log 3 sets with weight stepper, rest timer starts, skip rest
7. **Session survives reload** (sets and position restored)
8. Substitute an exercise (sets already logged stay with the original)
9. Pain report with "chest pain and dizzy" → emergency message, no substitute offered
10. Finish early → honest partial summary ("3 / 21 sets done"), PRs attributed to the right exercise
11. Hydration add/delete/undo with live total
12. Nutrition search "roti" → add to breakfast
13. Measurements add waist → Progress weight chart → Strength tab PRs
14. Recovery check-in saves → weekly review renders recommendations from data
15. AI coach off → graceful fallback message
16. Reminders, Devices, Privacy, Improve screens render; request submitted
17. No uncaught page errors

## Static checks

`tsc --noEmit` strict: PASS. `vite build`: PASS (603 kB JS, 165 kB gzipped).

## Gemini proxy (`gemini-proxy/server.mjs`)

Starts, refuses to start without key, `/health` OK, `/v1/generate` validates body and forwards — PASS.
Upstream call to `generativelanguage.googleapis.com`: **BLOCKED** in this environment (host not allowed); the real
round-trip has not been observed. Direct mode from the phone: NOT TESTED.

## Android / device

| Item | Status |
|---|---|
| `npx cap add android` + `cap sync` (manifest, permissions, icons, splash, backup rules) | PASS |
| `gradle assembleDebug` | **BLOCKED** — AGP 8.13 / androidx / Android SDK platform 36 could not be downloaded |
| APK produced and installed | **NOT DONE** |
| Native SQLite driver on device | NOT TESTED (compiles against plugin types) |
| Local notifications delivery, quiet hours, snooze on device | NOT TESTED |
| Health Connect connect / denied / revoked / sync / dedupe on device | NOT TESTED |
| Share-sheet export on device | NOT TESTED |
| Small-screen usability | Verified at 390×844 in Chromium only |

## Not tested / not applicable

Account/auth isolation (no accounts by design), cloud sync conflicts (no backend), Fitbit/Garmin (not implemented),
iOS (not applicable).

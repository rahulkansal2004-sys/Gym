import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.chirag.fitcoach',
  appName: 'FitCoach',
  webDir: 'dist',
  android: { allowMixedContent: true }, // needed only so the WebView (https://localhost) may call the plain-http Gemini proxy on your LAN
  plugins: {
    CapacitorSQLite: {
      androidIsEncryption: false,
      androidBiometric: { biometricAuth: false },
    },
    LocalNotifications: {
      smallIcon: 'ic_stat_fitcoach',
      iconColor: '#1D6AE5',
    },
  },
};

export default config;

// FitCoach Gemini proxy — runs on YOUR computer, keeps GEMINI_API_KEY off the phone.
// Zero dependencies (Node 18+). Usage:
//   cp gemini-proxy/.env.example gemini-proxy/.env   # put your key in it
//   node gemini-proxy/server.mjs                      # listens on 0.0.0.0:8787
// Then in the app: Settings > AI coach > mode "Proxy", address http://<your-computer-LAN-IP>:8787
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
loadDotEnv(path.join(here, '.env'));

const PORT = Number(process.env.PORT ?? 8787);
const KEY = process.env.GEMINI_API_KEY;
const TOKEN = process.env.PROXY_TOKEN ?? '';
const ALLOWED_MODELS = (process.env.ALLOWED_MODELS ?? 'gemini-2.5-flash,gemini-2.5-flash-lite,gemini-2.5-pro,gemini-2.0-flash').split(',');
const MAX_PER_MINUTE = Number(process.env.MAX_PER_MINUTE ?? 20);
const MAX_BODY = 64 * 1024;

if (!KEY) {
  console.error('GEMINI_API_KEY is not set. Copy gemini-proxy/.env.example to gemini-proxy/.env and add your key.');
  process.exit(1);
}

const calls = []; // timestamps for a simple sliding-window rate limit

const server = http.createServer(async (req, res) => {
  cors(res);
  if (req.method === 'OPTIONS') return res.writeHead(204).end();
  if (req.method === 'GET' && req.url === '/health') return json(res, 200, { ok: true, models: ALLOWED_MODELS, tokenRequired: !!TOKEN });
  if (req.method !== 'POST' || req.url !== '/v1/generate') return json(res, 404, { error: 'not found' });
  if (TOKEN && req.headers['x-proxy-token'] !== TOKEN) return json(res, 401, { error: 'bad token' });

  const now = Date.now();
  while (calls.length && calls[0] < now - 60000) calls.shift();
  if (calls.length >= MAX_PER_MINUTE) return json(res, 429, { error: 'proxy rate limit' });
  calls.push(now);

  let raw = '';
  req.on('data', (c) => { raw += c; if (raw.length > MAX_BODY) req.destroy(); });
  req.on('end', async () => {
    let payload;
    try { payload = JSON.parse(raw); } catch { return json(res, 400, { error: 'invalid json' }); }
    const model = ALLOWED_MODELS.includes(payload.model) ? payload.model : ALLOWED_MODELS[0];
    const body = payload.body;
    if (!body || !Array.isArray(body.contents)) return json(res, 400, { error: 'body.contents required' });
    body.generationConfig = { ...(body.generationConfig ?? {}), maxOutputTokens: Math.min(1200, body.generationConfig?.maxOutputTokens ?? 700) };
    try {
      const up = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, {
        method: 'POST', headers: { 'content-type': 'application/json', 'x-goog-api-key': KEY }, body: JSON.stringify(body),
      });
      const text = await up.text();
      res.writeHead(up.status, { 'content-type': 'application/json' });
      res.end(text);
      console.log(new Date().toISOString(), model, up.status, `${raw.length}B in`);
    } catch (e) {
      json(res, 502, { error: 'upstream failed: ' + e.message });
    }
  });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`FitCoach Gemini proxy listening on port ${PORT}`);
  for (const [name, addrs] of Object.entries(os.networkInterfaces())) {
    for (const a of addrs ?? []) if (a.family === 'IPv4' && !a.internal) console.log(`  phone address: http://${a.address}:${PORT}  (${name})`);
  }
  console.log(TOKEN ? '  PROXY_TOKEN is set: enter the same token in the app.' : '  Tip: set PROXY_TOKEN in .env so other devices on your Wi-Fi cannot use your key.');
});

function cors(res) {
  res.setHeader('access-control-allow-origin', '*');
  res.setHeader('access-control-allow-headers', 'content-type, x-proxy-token');
  res.setHeader('access-control-allow-methods', 'POST, GET, OPTIONS');
}
function json(res, code, obj) { res.writeHead(code, { 'content-type': 'application/json' }); res.end(JSON.stringify(obj)); }
function loadDotEnv(file) {
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, 'utf8').split('\n')) {
    const m = line.match(/^\s*([A-Z_]+)\s*=\s*(.*)\s*$/);
    if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
}

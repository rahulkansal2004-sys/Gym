package com.chirag.fitcoach;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
